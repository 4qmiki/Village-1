# Hollowmere | A Medieval Exploration (Rust / Bevy / wgpu / Rapier3D / Android)

A faithful Rust port of **Hollowmere | A Medieval Exploration**, preserving every map coordinate, 12 medieval buildings (7 enterable, including the 2-story *Traveler's Rest*), 10 villagers with A* schedules and combat reactions, 3 rideable horses, Lake Mere with custom WGSL water/foliage/sky shaders, procedural PBR textures, procedural audio synthesis, quests, fishing minigame, sword combat, and touch controls.

## 1. Prepare Ubuntu Environment

```bash
chmod +x scripts/setup_ubuntu_android_rust.sh scripts/build_apk.sh
./scripts/setup_ubuntu_android_rust.sh
source ~/.bashrc
```

## 2. Run & Test on Desktop Linux

```bash
cargo test --lib
cargo run --release --bin hollowmere-desktop
```

## 3. Build Installable Android APK

```bash
./scripts/build_apk.sh
# Output: android/app/build/outputs/apk/debug/app-debug.apk
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

## 4. `rust-anything` Verification Workflow

```bash
rust-anything doctor
cargo test --lib
```

See `MIGRATION_PLAN.md` for the full module-by-module mapping against the original HTML/JS implementation.
