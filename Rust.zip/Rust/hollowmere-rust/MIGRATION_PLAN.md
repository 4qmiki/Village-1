# Hollowmere — `rust-anything` Migration Plan & Parity Architecture

Source analyzed: `Hollowmere _ A Medieval Exploration (8).html` (single-file Three.js + WebAudio + HTML5 Canvas medieval village exploration game).

## 1. Migration Waves (`rust-anything` Methodology)

| Wave | Unit / Module | Original JS Source | Target Rust Module | Parity & Verification Strategy |
| :--- | :--- | :--- | :--- | :--- |
| **Wave 1 (`start_here`)** | Deterministic Math & Noise | `seeded()`, `noiseTable` (seed 981), `noise()`, `fbm()`, `smooth()`, `distSeg()` | `src/math.rs` | Bit-exact Mulberry32 PRNG; `rust-anything record/diff` with `--float-tolerance 1e-6` |
| **Wave 1 (`start_here`)** | Static World Data | `BUILDINGS` (12), `PEOPLE` (10), `PATHS` (8), `HORSES` (3), `DUMMIES` (2), `CONTROL_LIST` (20) | `src/data.rs` | Exact constants, coordinates, dialogues, and quest definitions |
| **Wave 1 (`start_here`)** | Terrain & Surface Queries | `Terrain` (`lake`, `height`, `path`, `dock`, `inside`, `stairInfo`, `walk`, `surface`) | `src/terrain.rs` | Deterministic height & surface sampling verified against JS |
| **Wave 2** | Spatial Collision & Physics | `OBSTACLES`, `COL_GRID` (6m cell), `DOORS`, `blocked()`, `hitObstacle()`, `hitObstacle3D()` | `src/collision.rs` | Analytical parity + `bevy_rapier3d` static/kinematic colliders |
| **Wave 2** | 8-Connected A* Navigation | `findPath()` (2.1m cell, 1100-iter cap, diagonal corner-cut guard) | `src/pathfinding.rs` | Exact grid heuristic & tie-breaking |
| **Wave 2** | Simulation, Quests & Combat | `Player`, `NPC`, `NPCManager`, `World` (15-min timer, quests, fishing, renown, sword combat) | `src/player.rs`, `src/npc.rs`, `src/world_state.rs` | Stateful step-by-step parity + unit tests |
| **Wave 3** | Procedural PBR Textures & Shaders | `surface()`, `makeNormalAndORM()`, `CharMat`, `makeHorseCoatMat()`, `foliageShader()`, `Water`, `skyMat` | `src/procedural_textures.rs`, `assets/shaders/*.wgsl` | Procedural 512x512 albedo/normal/ORM images + native WGSL shaders (`wgpu`) |
| **Wave 3** | World Geometry, Actors & Horses | `Village`, `Lake`, `Vegetation`, `Actor`, `HGeo`, `Horse`, `fpRig`, `Atmosphere` | `src/village.rs`, `src/lake_and_foliage.rs`, `src/characters.rs`, `src/lighting_and_fx.rs` | Bevy 0.15 `Mesh` + `StandardMaterial` + `DirectionalLight`/`PointLight` + frustum culling |
| **Wave 4** | Procedural Audio Synthesizer | `AudioManager` (wind/water/rain/fire/tavern beds, pentatonic melody, birds/owls, footsteps, SFX) | `src/audio.rs` | Pure Rust procedural PCM synth fed into Bevy Audio |
| **Wave 4** | Full UI, Menus & Touch Controls | `UI`, `App`, `Art` (3 vistas), HUD, Dialogue, Journal (4 tabs), Settings, Pause, Photo, Cinematic, Touch Stick | `src/ui.rs` | Bevy UI with full touch joystick + swipe look + action buttons |
| **Wave 5** | Android NDK & Gradle APK | Browser DOM / Pointer Events | `android/` + `scripts/build_apk.sh` | `cargo-ndk` (`arm64-v8a`) + Android `GameActivity` + Gradle APK |

## 2. Preserved Feature Checklist (Zero Simplifications)

- **12 Buildings**: The Gilded Heron (enterable inn + hearth/bar/tables/chandelier), Rowan's Forge (enterable + anvil/racks/hearth), Saint Mere Chapel (enterable + bell tower/altar/pews), The Old Mill (rotating waterwheel), Fisherman's Rest, Hillgate Stable (fences/hay), Mara's Bakery & Goods (enterable + oven/bread/cheese), Amberfield Farm (carrot rows), The Weavers' House (enterable + loom/dye vats), Hearthroot Apothecary (enterable + potions/herbs), Northwatch Lodge, and Traveler's Rest (enterable 2-story player home with walkable 13-step staircase & bedroom).
- **10 Villagers with Daily Schedules & Combat Reactions**: Elin, Rowan, Bram (dock fishing), Alys, Oswin (guard with defensive sword stance), Brother Alden, Mara, Pip, Edric, Nessa.
- **3 Rideable Horses**: Black Friesian, Dapple-Grey Courser, Chestnut Warmblood (walk, gallop, jump, graze, mount/dismount).
- **Gameplay & Quests**: 15-minute visit clock, Supper at the Heron (catch 3 silver perch in the fishing minigame), A craftsman's companion (recover Rowan's hammer), 6 collectible Merebell flowers, Wishing Well, 2 sparring dummies, 3-hit sword combo + heavy cleave + guard/block + draw/sheathe, eating bread/stew, lantern toggle, interactive hinged doors, bed rest until morning.
- **Camera & Modes**: 1st-person (with articulated viewmodel for sword, bread, fishing rod) and 3rd-person (with obstacle pullback), Photo mode (orbit + zoom), Cinematic tour (8-point Catmull-Rom spline), Time speed (1x / 25x / pause), Weather (Clear / Mist / Rain), Quality tiers (Low / Medium / High / Ultra).

## 3. Running `rust-anything` Verification on Ubuntu

Once you run `scripts/setup_ubuntu_android_rust.sh` on Ubuntu:

```bash
cargo install rust-anything
rust-anything setup
rust-anything doctor
cargo test --lib
```
