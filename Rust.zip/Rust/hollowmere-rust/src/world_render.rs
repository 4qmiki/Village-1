use std::f32::consts::{FRAC_PI_2, PI, TAU};

use bevy::prelude::*;
use bevy::render::mesh::{Indices, PrimitiveTopology};
use bevy::render::render_asset::RenderAssetUsages;
use bevy::render::render_resource::{AsBindGroup, ShaderRef};
use bevy_rapier3d::prelude::*;

use crate::data::{AppScreen, BuildingKind, WeatherKind, HORSES, PEOPLE};
use crate::math::{clamp, fbm, mix, noise, smooth, SeededRng};
use crate::procedural_textures::{create_materials, HollowmereMaterials};
use crate::terrain::Terrain;
use crate::world_state::HollowmereWorld;

#[derive(Asset, TypePath, AsBindGroup, Debug, Clone)]
pub struct SkyMaterial {
    #[uniform(0)]
    pub sun_dir: Vec3,
    #[uniform(0)]
    pub day: f32,
    #[uniform(0)]
    pub wet: f32,
    #[uniform(0)]
    pub time: f32,
    #[uniform(0)]
    pub _pad: Vec2,
}

impl Material for SkyMaterial {
    fn fragment_shader() -> ShaderRef {
        "shaders/sky.wgsl".into()
    }
    fn alpha_mode(&self) -> AlphaMode {
        AlphaMode::Opaque
    }
}

#[derive(Asset, TypePath, AsBindGroup, Debug, Clone)]
pub struct WaterMaterial {
    #[uniform(0)]
    pub sun_dir: Vec3,
    #[uniform(0)]
    pub time: f32,
    #[uniform(0)]
    pub sun_color: Vec3,
    #[uniform(0)]
    pub wetness: f32,
    #[uniform(0)]
    pub water_color: Vec3,
    #[uniform(0)]
    pub day: f32,
    #[uniform(0)]
    pub ripple_event: Vec3,
    #[uniform(0)]
    pub _pad: f32,
}

impl Material for WaterMaterial {
    fn fragment_shader() -> ShaderRef {
        "shaders/water.wgsl".into()
    }
    fn alpha_mode(&self) -> AlphaMode {
        AlphaMode::Blend
    }
}

#[derive(Component)]
pub struct MainCamera;

#[derive(Component)]
pub struct SunLight;

#[derive(Component)]
pub struct LanternLight;

#[derive(Component)]
pub struct MillWheel;

#[derive(Component)]
pub struct DoorPivot(pub usize);

#[derive(Component)]
pub struct DummyVisual(pub usize);

#[derive(Component)]
pub struct FlowerVisual(pub usize);

#[derive(Component)]
pub struct HammerVisual;

#[derive(Component)]
pub struct RowboatVisual;

#[derive(Component)]
pub struct JumpingFishVisual;

#[derive(Component)]
pub struct PlayerVisual;

#[derive(Component)]
pub struct NpcVisual(pub usize);

#[derive(Component)]
pub struct HorseVisual(pub usize);

#[derive(Component)]
pub struct FlameVisual(pub f32);

#[derive(Resource)]
pub struct ShaderHandles {
    pub sky: Handle<SkyMaterial>,
    pub water: Handle<WaterMaterial>,
}

pub fn setup_3d_world(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut images: ResMut<Assets<Image>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut sky_mats: ResMut<Assets<SkyMaterial>>,
    mut water_mats: ResMut<Assets<WaterMaterial>>,
    mut world: ResMut<HollowmereWorld>,
) {
    let mats = create_materials(&mut images, &mut materials);
    let mut rng = SeededRng::new(77231);

    // 1. Valley Terrain Mesh (285x285, 188x188 subdivisions) + Rapier3D Trimesh Collider
    let (terrain_mesh, terrain_verts, terrain_indices) = build_terrain_mesh();
    commands.spawn((
        Mesh3d(meshes.add(terrain_mesh)),
        MeshMaterial3d(mats.grass.clone()),
        RigidBody::Fixed,
        Collider::trimesh(terrain_verts, terrain_indices),
    ));

    // 2. Three-Tier Alpine Mountain Rings
    let mountain_mesh = build_mountain_rings();
    commands.spawn((
        Mesh3d(meshes.add(mountain_mesh)),
        MeshMaterial3d(mats.mountain.clone()),
    ));

    // 3. Procedural Sky Dome (WGSL)
    let sky_handle = sky_mats.add(SkyMaterial {
        sun_dir: Vec3::new(-0.7, 0.25, -0.6).normalize(),
        day: 1.0,
        wet: 0.0,
        time: 0.0,
        _pad: Vec2::ZERO,
    });
    commands.spawn((
        Mesh3d(meshes.add(Sphere::new(435.0))),
        MeshMaterial3d(sky_handle.clone()),
        Transform::from_scale(Vec3::new(-1.0, 1.0, 1.0)),
    ));

    // 4. Lake Mere Water Plane (WGSL) + Dock + Rowboat + Jumping Fish
    let water_handle = water_mats.add(WaterMaterial {
        sun_dir: Vec3::new(-0.7, 0.25, -0.6).normalize(),
        time: 0.0,
        sun_color: Vec3::new(1.0, 0.9, 0.7),
        wetness: 0.0,
        water_color: Vec3::new(0.25, 0.42, 0.38),
        day: 1.0,
        ripple_event: Vec3::new(-14.0, 0.0, -100.0),
        _pad: 0.0,
    });
    commands.spawn((
        Mesh3d(meshes.add(Plane3d::default().mesh().size(99.0, 116.0))),
        MeshMaterial3d(water_handle.clone()),
        Transform::from_xyz(-53.0, 0.1, -18.0),
    ));
    spawn_dock_and_lake_props(&mut commands, &mut meshes, &mats, &mut world, &mut rng);

    // 5. All 12 Medieval Buildings + Furnished Interiors + Hinged Doors + Village Square
    let buildings = world.buildings.clone();
    let mut door_idx = 0usize;
    for b in &buildings {
        spawn_building(&mut commands, &mut meshes, &mats, b, &mut door_idx);
    }
    spawn_village_square_and_props(&mut commands, &mut meshes, &mats, &mut world, &mut rng);

    // 6. Woodland Trees (Pine, Oak, Birch) & Meadow Grass
    spawn_vegetation(&mut commands, &mut meshes, &mats, &mut world, &mut rng);

    // 7. Player Avatar, 10 Villagers, 3 Rideable Horses, Quest Items
    spawn_humanoid(&mut commands, &mut meshes, &mut materials, &mats, Color::srgb_u8(79, 107, 86), 1.0, PlayerVisual);
    for p in PEOPLE {
        let scale = if p.id == 7 { 0.74 } else if p.id == 1 { 1.05 } else { 1.0 };
        spawn_humanoid(
            &mut commands,
            &mut meshes,
            &mut materials,
            &mats,
            crate::data::hex_to_color(p.color_hex),
            scale,
            NpcVisual(p.id),
        );
    }
    for (i, h) in HORSES.iter().enumerate() {
        spawn_horse(&mut commands, &mut meshes, &mut materials, &mats, h.coat_rgb, i);
    }

    // Rowan's Lost Hammer
    let hy = Terrain::walk(&world.buildings, -5.7, 3.65, None);
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(0.24, 0.24, 0.55))),
        MeshMaterial3d(mats.iron.clone()),
        Transform::from_xyz(-5.7, hy + 0.25, 3.65),
        HammerVisual,
    ));

    // 6 Collectible Merebell Flowers
    for (i, f) in world.flowers.iter().enumerate() {
        let fy = Terrain::walk(&world.buildings, f.x, f.z, None);
        commands.spawn((
            Mesh3d(meshes.add(Sphere::new(0.18))),
            MeshMaterial3d(mats.gold.clone()),
            Transform::from_xyz(f.x, fy + 0.35, f.z),
            FlowerVisual(i),
        ));
    }

    // 8. Lighting & Camera
    commands.insert_resource(AmbientLight {
        color: Color::srgb_u8(232, 217, 181),
        brightness: 420.0,
    });
    commands.spawn((
        DirectionalLight {
            color: Color::srgb_u8(255, 218, 160),
            illuminance: 24_000.0,
            shadows_enabled: true,
            ..default()
        },
        Transform::from_xyz(-45.0, 38.0, -35.0).looking_at(Vec3::new(8.0, 0.0, -4.0), Vec3::Y),
        SunLight,
    ));
    commands.spawn((
        PointLight {
            color: Color::srgb_u8(255, 181, 85),
            intensity: 0.0,
            range: 13.5,
            ..default()
        },
        Transform::from_xyz(5.4, 2.5, 23.0),
        LanternLight,
    ));

    commands.spawn((
        Camera3d::default(),
        Projection::Perspective(PerspectiveProjection {
            fov: 57.0_f32.to_radians(),
            near: 0.09,
            far: 510.0,
            ..default()
        }),
        DistanceFog {
            color: Color::srgb_u8(200, 206, 184),
            falloff: FogFalloff::Exponential { density: 0.0043 },
            ..default()
        },
        Transform::from_xyz(12.0, 8.0, 35.0).looking_at(Vec3::new(5.4, 2.5, 23.0), Vec3::Y),
        MainCamera,
    ));

    commands.insert_resource(mats);
    commands.insert_resource(ShaderHandles {
        sky: sky_handle,
        water: water_handle,
    });
}

fn build_terrain_mesh() -> (Mesh, Vec<Vec3>, Vec<[u32; 3]>) {
    let segs = 128usize;
    let size = 285.0f32;
    let half = size * 0.5;
    let mut positions = Vec::with_capacity((segs + 1) * (segs + 1));
    let mut normals = Vec::with_capacity((segs + 1) * (segs + 1));
    let mut uvs = Vec::with_capacity((segs + 1) * (segs + 1));
    let mut colors = Vec::with_capacity((segs + 1) * (segs + 1));
    let mut rapier_verts = Vec::with_capacity((segs + 1) * (segs + 1));

    for iz in 0..=segs {
        for ix in 0..=segs {
            let x = -half + (ix as f32 / segs as f32) * size;
            let z = -half + (iz as f32 / segs as f32) * size;
            let h = Terrain::height(x, z);
            let hx = Terrain::height(x + 1.0, z);
            let hz = Terrain::height(x, z + 1.0);
            let n_vec = Vec3::new(h - hx, 1.0, h - hz).normalize();
            let n = fbm(x * 0.13, z * 0.13);
            let d = Terrain::path(x, z);
            let slope = (h - hx).abs() + (h - hz).abs();

            let mut r = mix(0.537, 0.396, n);
            let mut g = mix(0.588, 0.498, n);
            let mut b = mix(0.333, 0.306, n);
            let rock_t = clamp(slope * 0.74, 0.0, 1.0);
            r = mix(r, 0.56, rock_t);
            g = mix(g, 0.58, rock_t);
            b = mix(b, 0.51, rock_t);
            let sand_t = 1.0 - smooth(0.3, 1.6, h);
            r = mix(r, 0.63, sand_t);
            g = mix(g, 0.59, sand_t);
            b = mix(b, 0.46, sand_t);
            let path_t = 1.0 - smooth(1.1, 2.4, d);
            r = mix(r, 0.76, path_t);
            g = mix(g, 0.69, path_t);
            b = mix(b, 0.52, path_t);
            let mul = 0.81 + n * 0.37;

            positions.push([x, h, z]);
            rapier_verts.push(Vec3::new(x, h, z));
            normals.push([n_vec.x, n_vec.y, n_vec.z]);
            uvs.push([x * 0.34, z * 0.34]);
            colors.push([r * mul, g * mul, b * mul, 1.0]);
        }
    }

    let stride = (segs + 1) as u32;
    let mut indices = Vec::with_capacity(segs * segs * 6);
    let mut rapier_tris = Vec::with_capacity(segs * segs * 2);
    for iz in 0..segs as u32 {
        for ix in 0..segs as u32 {
            let a = iz * stride + ix;
            let b = a + 1;
            let c = a + stride;
            let d = c + 1;
            indices.extend_from_slice(&[a, c, b, b, c, d]);
            rapier_tris.push([a, c, b]);
            rapier_tris.push([b, c, d]);
        }
    }

    let mut mesh = Mesh::new(PrimitiveTopology::TriangleList, RenderAssetUsages::RENDER_WORLD);
    mesh.insert_attribute(Mesh::ATTRIBUTE_POSITION, positions);
    mesh.insert_attribute(Mesh::ATTRIBUTE_NORMAL, normals);
    mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, uvs);
    mesh.insert_attribute(Mesh::ATTRIBUTE_COLOR, colors);
    mesh.insert_indices(Indices::U32(indices));
    (mesh, rapier_verts, rapier_tris)
}

fn build_mountain_rings() -> Mesh {
    let mut positions = Vec::new();
    let mut normals = Vec::new();
    let mut uvs = Vec::new();
    let mut colors = Vec::new();
    let ridged = |x: f32, y: f32| {
        let n1 = 1.0 - (fbm(x, y) * 2.0 - 1.0).abs();
        let n2 = 1.0 - (fbm(x * 2.2 + 7.0, y * 2.2 + 3.0) * 2.0 - 1.0).abs();
        n1 * n1 * 0.68 + n2 * n2 * 0.32
    };
    let n_seg = 120usize;
    let l_seg = 10usize;
    for level in 0..3usize {
        let rad = 134.0 + level as f32 * 56.0;
        let pt = |i: usize, j: usize| -> ([f32; 3], [f32; 4], [f32; 2]) {
            let a = (i as f32 / n_seg as f32) * TAU;
            let k = j as f32 / l_seg as f32;
            let radius = rad + k * 44.0;
            let ridge_h = ridged(a.cos() * 2.6 + level as f32 * 3.1, a.sin() * 2.6 + level as f32 * 1.7);
            let detail = fbm(a.cos() * 8.0 + level as f32, a.sin() * 8.0) * 22.0 + noise(a * 29.0, level as f32) * 9.0;
            let peak = 24.0 + level as f32 * 18.0 + ridge_h * 88.0 + detail;
            let y = (k * PI * 0.9).sin().max(0.0).powf(1.15) * peak - 7.0;
            let x = a.sin() * radius;
            let z = a.cos() * radius;
            let snow = smooth(44.0 + level as f32 * 8.0, 78.0 + level as f32 * 11.0, y);
            let rock = smooth(10.0, 36.0 + level as f32 * 6.0, y);
            let r = mix(mix(0.38, 0.56, rock), 0.92, snow);
            let g = mix(mix(0.47, 0.58, rock), 0.91, snow);
            let b = mix(mix(0.41, 0.54, rock), 0.87, snow);
            ([x, y, z], [r, g, b, 1.0], [i as f32 / n_seg as f32, k])
        };
        for i in 0..n_seg {
            for j in 0..l_seg {
                let p00 = pt(i, j);
                let p01 = pt(i, j + 1);
                let p10 = pt(i + 1, j);
                let p11 = pt(i + 1, j + 1);
                for (pos, col, uv) in [p00, p01, p10, p10, p01, p11] {
                    positions.push(pos);
                    normals.push([0.0, 1.0, 0.0]);
                    colors.push(col);
                    uvs.push(uv);
                }
            }
        }
    }
    let mut mesh = Mesh::new(PrimitiveTopology::TriangleList, RenderAssetUsages::RENDER_WORLD);
    mesh.insert_attribute(Mesh::ATTRIBUTE_POSITION, positions);
    mesh.insert_attribute(Mesh::ATTRIBUTE_NORMAL, normals);
    mesh.insert_attribute(Mesh::ATTRIBUTE_UV_0, uvs);
    mesh.insert_attribute(Mesh::ATTRIBUTE_COLOR, colors);
    mesh
}

fn spawn_building(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    mats: &HollowmereMaterials,
    b: &crate::data::BuildingSpec,
    door_idx: &mut usize,
) {
    let y = if b.enterable {
        b.floor_y - 0.12
    } else {
        Terrain::height(b.x, b.z) - 0.08
    };
    let front = b.z + b.d * 0.5;
    let top = y + b.h;
    let wall_mat = match b.kind {
        BuildingKind::Chapel => mats.stone.clone(),
        BuildingKind::Stable => mats.lightwood.clone(),
        _ => mats.plaster.clone(),
    };
    let roof_mat = match b.kind {
        BuildingKind::Inn | BuildingKind::Hut | BuildingKind::Farm | BuildingKind::Stable => mats.thatch.clone(),
        _ => mats.slate.clone(),
    };

    if !b.enterable {
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(b.w + 0.17, 0.83, b.d + 0.16))),
            MeshMaterial3d(mats.stone.clone()),
            Transform::from_xyz(b.x, y + 0.33, b.z),
        ));
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(b.w, b.h - 0.55, b.d))),
            MeshMaterial3d(wall_mat.clone()),
            Transform::from_xyz(b.x, y + (b.h + 0.56) * 0.5, b.z),
            RigidBody::Fixed,
            Collider::cuboid(b.w * 0.5, b.h * 0.5, b.d * 0.5),
        ));
    } else {
        let wt = 0.24;
        let hw = b.w * 0.5;
        let hd = b.d * 0.5;
        let side_w = (b.w - b.door_w) * 0.5;
        // Stone plinth & floor
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(b.w + 0.22, 0.92, b.d + 0.22))),
            MeshMaterial3d(mats.stone.clone()),
            Transform::from_xyz(b.x, y - 0.28, b.z),
        ));
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(b.w - 0.16, 0.16, b.d - 0.16))),
            MeshMaterial3d(if b.floor_type == crate::data::FloorType::Stone {
                mats.stone.clone()
            } else {
                mats.lightwood.clone()
            }),
            Transform::from_xyz(b.x, b.floor_y - 0.08, b.z),
        ));
        // Back, left, right, and split front walls
        for (px, py, pz, sx, sy, sz) in [
            (b.x, y + b.h * 0.5, b.z - hd + wt * 0.5, b.w, b.h, wt),
            (b.x - hw + wt * 0.5, y + b.h * 0.5, b.z, wt, b.h, b.d),
            (b.x + hw - wt * 0.5, y + b.h * 0.5, b.z, wt, b.h, b.d),
            (b.x - hw + side_w * 0.5, y + b.h * 0.5, front - wt * 0.5, side_w, b.h, wt),
            (b.x + hw - side_w * 0.5, y + b.h * 0.5, front - wt * 0.5, side_w, b.h, wt),
        ] {
            commands.spawn((
                Mesh3d(meshes.add(Cuboid::new(sx, sy, sz))),
                MeshMaterial3d(wall_mat.clone()),
                Transform::from_xyz(px, py, pz),
            ));
        }
        let header_h = (b.h - b.door_h).max(0.35);
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(b.door_w + 0.08, header_h, wt))),
            MeshMaterial3d(wall_mat.clone()),
            Transform::from_xyz(b.x, y + b.door_h + header_h * 0.5, front - wt * 0.5),
        ));

        // Working hinged door pivot
        let cur_door = *door_idx;
        *door_idx += 1;
        let dw = b.door_w;
        let dh = b.door_h;
        commands
            .spawn((
                Transform::from_xyz(b.x - dw * 0.5 + 0.02, b.floor_y, front - 0.04),
                Visibility::Visible,
                DoorPivot(cur_door),
            ))
            .with_children(|parent| {
                parent.spawn((
                    Mesh3d(meshes.add(Cuboid::new(dw * 0.96, dh * 0.96, 0.11))),
                    MeshMaterial3d(mats.lightwood.clone()),
                    Transform::from_xyz(dw * 0.48, dh * 0.48, 0.0),
                ));
            });

        // Two-story Traveler's Rest staircase & second floor bedroom
        if b.two_story {
            let st = Terrain::stair_info(b);
            for i in 0..13 {
                let u = (i as f32 + 0.5) / 13.0;
                let sz = mix(st.z_bot, st.z_top, u);
                let sy = mix(b.floor_y, st.y2, u);
                commands.spawn((
                    Mesh3d(meshes.add(Cuboid::new(st.x1 - st.x0, 0.16, (st.z_bot - st.z_top) / 13.0 + 0.06))),
                    MeshMaterial3d(mats.lightwood.clone()),
                    Transform::from_xyz((st.x0 + st.x1) * 0.5, sy - 0.08, sz),
                ));
            }
            let stair_right = st.x1 + 0.06;
            let main_w = (b.x + hw) - stair_right;
            commands.spawn((
                Mesh3d(meshes.add(Cuboid::new(main_w, 0.18, b.d - 0.36))),
                MeshMaterial3d(mats.lightwood.clone()),
                Transform::from_xyz(stair_right + main_w * 0.5, st.y2 - 0.1, b.z),
            ));
            // Four-poster oak bed on 2nd floor
            commands.spawn((
                Mesh3d(meshes.add(Cuboid::new(2.1, 0.55, 1.62))),
                MeshMaterial3d(mats.rug.clone()),
                Transform::from_xyz(b.x + 1.95, st.y2 + 0.42, b.z - 1.25),
            ));
        }

        // Interior furnishings per building kind
        if b.kind == BuildingKind::Inn {
            commands.spawn((
                Mesh3d(meshes.add(Cuboid::new(0.88, 1.08, 3.55))),
                MeshMaterial3d(mats.wood.clone()),
                Transform::from_xyz(b.x - hw + 1.55, b.floor_y + 0.54, b.z - 0.55),
            ));
            commands.spawn((
                Mesh3d(meshes.add(Cone::new(0.2, 0.45))),
                MeshMaterial3d(mats.fire.clone()),
                Transform::from_xyz(b.x + hw - 0.55, b.floor_y + 0.42, b.z - hd + 0.8),
                FlameVisual(0.45),
            ));
        } else if b.kind == BuildingKind::Chapel {
            commands.spawn((
                Mesh3d(meshes.add(Cuboid::new(1.85, 1.05, 0.92))),
                MeshMaterial3d(mats.stone.clone()),
                Transform::from_xyz(b.x, b.floor_y + 0.62, b.z - hd + 1.15),
            ));
        }
    }

    // Pitched Roof Slopes
    let rw = b.w + 0.94;
    let rd = b.d + 0.98;
    let rh = b.roof + 0.15;
    let slope_len = (rw * 0.5).hypot(rh) + 0.18;
    let angle = rh.atan2(rw * 0.5);
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(slope_len, 0.2, rd))),
        MeshMaterial3d(roof_mat.clone()),
        Transform::from_xyz(b.x - rw * 0.25, top + rh * 0.5 - 0.07, b.z)
            .with_rotation(Quat::from_rotation_z(angle)),
    ));
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(slope_len, 0.2, rd))),
        MeshMaterial3d(roof_mat),
        Transform::from_xyz(b.x + rw * 0.25, top + rh * 0.5 - 0.07, b.z)
            .with_rotation(Quat::from_rotation_z(-angle)),
    ));

    // Special landmarks: Chapel bell tower, Mill rotating waterwheel, Forge chimney
    if b.kind == BuildingKind::Chapel {
        let tx = b.x - b.w * 0.5 - 0.95;
        let tz = b.z - b.d * 0.18;
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(2.55, 10.4, 2.55))),
            MeshMaterial3d(mats.stone.clone()),
            Transform::from_xyz(tx, y + 5.2, tz),
        ));
        commands.spawn((
            Mesh3d(meshes.add(Cone::new(2.2, 6.85))),
            MeshMaterial3d(mats.slate.clone()),
            Transform::from_xyz(tx, y + 13.8, tz),
        ));
    } else if b.kind == BuildingKind::Mill {
        commands.spawn((
            Mesh3d(meshes.add(Torus::new(0.16, 2.08))),
            MeshMaterial3d(mats.darkwood.clone()),
            Transform::from_xyz(b.x - b.w * 0.5 - 0.57, y + 1.58, b.z)
                .with_rotation(Quat::from_rotation_y(FRAC_PI_2)),
            MillWheel,
        ));
    }
}

fn spawn_dock_and_lake_props(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    mats: &HollowmereMaterials,
    world: &mut HollowmereWorld,
    rng: &mut SeededRng,
) {
    // Wooden dock planks extending from x=-4.05 to x=-18.5
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(14.6, 0.22, 2.78))),
        MeshMaterial3d(mats.lightwood.clone()),
        Transform::from_xyz(-11.1, 1.43, -0.85),
    ));
    for i in 0..6 {
        for s in [-1.0f32, 1.0] {
            let x = -4.6 - i as f32 * 2.68;
            let pz = -0.85 + s * 1.24;
            commands.spawn((
                Mesh3d(meshes.add(Cylinder::new(0.13, 3.25))),
                MeshMaterial3d(mats.darkwood.clone()),
                Transform::from_xyz(x, 0.5, pz),
            ));
            world.collision.add_circle(x, pz, 0.18, 2.2, -10.0);
        }
    }
    // Bobbing Rowboat
    commands.spawn((
        Mesh3d(meshes.add(Cuboid::new(4.6, 0.55, 1.55))),
        MeshMaterial3d(mats.wood.clone()),
        Transform::from_xyz(-16.1, 0.26, 2.6).with_rotation(Quat::from_rotation_y(0.15)),
        RowboatVisual,
    ));
    world.collision.add_wall_box(-16.1, 2.6, 4.8, 1.7, 1.4, -10.0);

    // Jumping lake fish
    commands.spawn((
        Mesh3d(meshes.add(Sphere::new(0.24))),
        MeshMaterial3d(mats.steel.clone()),
        Transform::from_xyz(-21.0, 0.1, -3.0).with_scale(Vec3::new(1.5, 0.55, 0.45)),
        JumpingFishVisual,
    ));

    // Shoreline rocks
    let rock_mesh = meshes.add(Sphere::new(0.5));
    for _ in 0..140 {
        let a = rng.next_f32() * TAU;
        let r = 0.985 + rng.next_f32() * 0.04;
        let x = -53.0 + a.sin() * 46.0 * r;
        let z = -18.0 + a.cos() * 54.0 * r;
        let y = Terrain::height(x, z);
        let sz = 0.18 + rng.next_f32() * 0.72;
        commands.spawn((
            Mesh3d(rock_mesh.clone()),
            MeshMaterial3d(mats.stone.clone()),
            Transform::from_xyz(x, y + 0.03, z).with_scale(Vec3::new(sz * 1.4, sz * 0.85, sz)),
        ));
    }
}

fn spawn_village_square_and_props(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    mats: &HollowmereMaterials,
    world: &mut HollowmereWorld,
    _rng: &mut SeededRng,
) {
    // Village Wishing Well
    let wy = Terrain::walk(&world.buildings, 9.5, -0.6, None);
    commands.spawn((
        Mesh3d(meshes.add(Cylinder::new(1.05, 0.92))),
        MeshMaterial3d(mats.stone.clone()),
        Transform::from_xyz(9.5, wy + 0.46, -0.6),
    ));
    commands.spawn((
        Mesh3d(meshes.add(Cone::new(1.7, 1.15))),
        MeshMaterial3d(mats.slate.clone()),
        Transform::from_xyz(9.5, wy + 3.25, -0.6),
    ));

    // Two Market Stalls
    for (cx, cz, w) in [(14.2f32, 1.4f32, 3.6f32), (18.0, 2.0, 2.5)] {
        let cy = Terrain::walk(&world.buildings, cx, cz, None);
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(w, 0.96, 1.65))),
            MeshMaterial3d(mats.lightwood.clone()),
            Transform::from_xyz(cx, cy + 0.48, cz),
        ));
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(w + 0.1, 0.12, 2.1))),
            MeshMaterial3d(mats.rug.clone()),
            Transform::from_xyz(cx, cy + 2.85, cz),
        ));
    }

    // Campfire at (3.5, -14.5)
    let fy = Terrain::walk(&world.buildings, 3.5, -14.5, None);
    commands.spawn((
        Mesh3d(meshes.add(Cone::new(0.28, 0.85))),
        MeshMaterial3d(mats.fire.clone()),
        Transform::from_xyz(3.5, fy + 0.48, -14.5),
        FlameVisual(0.85),
    ));
    world.collision.add_circle(3.5, -14.5, 0.82, fy + 1.2, -10.0);

    // Two Sparring Dummies
    for (i, dm) in world.collision.dummies.iter().enumerate() {
        commands.spawn((
            Mesh3d(meshes.add(Cylinder::new(0.24, 1.7))),
            MeshMaterial3d(mats.thatch.clone()),
            Transform::from_xyz(dm.x, dm.y + 0.85, dm.z),
            DummyVisual(i),
        ));
    }
}

fn spawn_vegetation(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    mats: &HollowmereMaterials,
    world: &mut HollowmereWorld,
    rng: &mut SeededRng,
) {
    let trunk_mesh = meshes.add(Cylinder::new(0.22, 4.2));
    let pine_cone = meshes.add(Cone::new(2.1, 6.2));
    let oak_crown = meshes.add(Sphere::new(2.4));

    let mut placed = 0usize;
    for _ in 0..900 {
        if placed >= 175 {
            break;
        }
        let x = (rng.next_f32() - 0.5) * 210.0;
        let z = (rng.next_f32() - 0.5) * 210.0;
        let y = Terrain::height(x, z);
        if Terrain::lake(x, z) < 1.05
            || Terrain::path(x, z) < 3.8
            || world.buildings.iter().any(|b| {
                (x - b.x).abs() < b.w * 0.5 + 3.6 && (z - b.z).abs() < b.d * 0.5 + 3.6
            })
        {
            continue;
        }
        if x > -10.0 && x < 49.0 && z > -56.0 && z < 45.0 && rng.next_f32() > 0.085 {
            continue;
        }
        if fbm(x * 0.038, z * 0.038) < 0.32 {
            continue;
        }
        let kind = if rng.next_f32() < 0.62 { 0 } else if rng.next_f32() < 0.65 { 1 } else { 2 };
        let scale = 0.72 + rng.next_f32() * 0.76;
        if (x - 5.0).abs() < 97.0 && z.abs() < 99.0 {
            world.collision.add_circle(x, z, 0.36 * scale, y + 7.5 * scale, -10.0);
        }
        let (t_mat, c_mesh, c_mat, crown_y) = match kind {
            0 => (mats.bark_oak.clone(), pine_cone.clone(), mats.pine_foliage.clone(), 5.4),
            1 => (mats.bark_oak.clone(), oak_crown.clone(), mats.oak_foliage.clone(), 5.1),
            _ => (mats.bark_birch.clone(), oak_crown.clone(), mats.birch_foliage.clone(), 5.3),
        };
        commands
            .spawn((
                Transform::from_xyz(x, y - 0.12, z).with_scale(Vec3::splat(scale)),
                Visibility::Visible,
            ))
            .with_children(|p| {
                p.spawn((
                    Mesh3d(trunk_mesh.clone()),
                    MeshMaterial3d(t_mat),
                    Transform::from_xyz(0.0, 2.1, 0.0),
                ));
                p.spawn((
                    Mesh3d(c_mesh),
                    MeshMaterial3d(c_mat),
                    Transform::from_xyz(0.0, crown_y, 0.0),
                ));
            });
        placed += 1;
    }
}

fn spawn_humanoid<M: Component>(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    materials: &mut Assets<StandardMaterial>,
    mats: &HollowmereMaterials,
    tunic_color: Color,
    scale: f32,
    marker: M,
) {
    let tunic = materials.add(StandardMaterial {
        base_color: tunic_color,
        perceptual_roughness: 0.88,
        ..default()
    });
    let skin = materials.add(StandardMaterial {
        base_color: Color::srgb_u8(209, 167, 130),
        perceptual_roughness: 0.62,
        ..default()
    });
    commands
        .spawn((
            Transform::from_scale(Vec3::splat(scale)),
            Visibility::Visible,
            marker,
        ))
        .with_children(|p| {
            p.spawn((
                Mesh3d(meshes.add(Capsule3d::new(0.22, 0.55))),
                MeshMaterial3d(tunic.clone()),
                Transform::from_xyz(0.0, 1.05, 0.0),
            ));
            p.spawn((
                Mesh3d(meshes.add(Sphere::new(0.16))),
                MeshMaterial3d(skin),
                Transform::from_xyz(0.0, 1.62, 0.0),
            ));
            for sx in [-0.11f32, 0.11] {
                p.spawn((
                    Mesh3d(meshes.add(Cylinder::new(0.075, 0.78))),
                    MeshMaterial3d(mats.darkwood.clone()),
                    Transform::from_xyz(sx, 0.39, 0.0),
                ));
            }
            for sx in [-0.28f32, 0.28] {
                p.spawn((
                    Mesh3d(meshes.add(Cylinder::new(0.062, 0.58))),
                    MeshMaterial3d(tunic.clone()),
                    Transform::from_xyz(sx, 1.12, 0.0),
                ));
            }
        });
}

fn spawn_horse(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    materials: &mut Assets<StandardMaterial>,
    mats: &HollowmereMaterials,
    coat_rgb: [u8; 3],
    idx: usize,
) {
    let coat = materials.add(StandardMaterial {
        base_color: Color::srgb_u8(coat_rgb[0], coat_rgb[1], coat_rgb[2]),
        perceptual_roughness: 0.44,
        ..default()
    });
    commands
        .spawn((Transform::default(), Visibility::Visible, HorseVisual(idx)))
        .with_children(|p| {
            p.spawn((
                Mesh3d(meshes.add(Capsule3d::new(0.33, 1.1))),
                MeshMaterial3d(coat.clone()),
                Transform::from_xyz(0.0, 1.22, 0.0).with_rotation(Quat::from_rotation_x(FRAC_PI_2)),
            ));
            p.spawn((
                Mesh3d(meshes.add(Cuboid::new(0.56, 0.12, 0.56))),
                MeshMaterial3d(mats.darkwood.clone()),
                Transform::from_xyz(0.0, 1.56, -0.02),
            ));
            p.spawn((
                Mesh3d(meshes.add(Capsule3d::new(0.17, 0.65))),
                MeshMaterial3d(coat.clone()),
                Transform::from_xyz(0.0, 1.62, 0.78).with_rotation(Quat::from_rotation_x(0.55)),
            ));
            for (lx, lz) in [(-0.24, 0.54), (0.24, 0.54), (-0.24, -0.56), (0.24, -0.56)] {
                p.spawn((
                    Mesh3d(meshes.add(Cylinder::new(0.075, 1.05))),
                    MeshMaterial3d(coat.clone()),
                    Transform::from_xyz(lx, 0.55, lz),
                ));
            }
        });
}

#[allow(clippy::too_many_arguments)]
pub fn sync_visuals_and_camera(
    time: Res<Time>,
    state: Res<State<AppScreen>>,
    world: Res<HollowmereWorld>,
    shaders: Option<Res<ShaderHandles>>,
    mut sky_mats: ResMut<Assets<SkyMaterial>>,
    mut water_mats: ResMut<Assets<WaterMaterial>>,
    mut cam_q: Query<(&mut Transform, &mut Projection, &mut DistanceFog), With<MainCamera>>,
    mut sun_q: Query<(&mut Transform, &mut DirectionalLight), (With<SunLight>, Without<MainCamera>)>,
    mut lantern_q: Query<(&mut Transform, &mut PointLight), (With<LanternLight>, Without<MainCamera>, Without<SunLight>)>,
    mut wheel_q: Query<&mut Transform, (With<MillWheel>, Without<MainCamera>, Without<SunLight>, Without<LanternLight>)>,
    mut door_q: Query<(&DoorPivot, &mut Transform), (Without<MainCamera>, Without<SunLight>, Without<LanternLight>, Without<MillWheel>)>,
    mut dummy_q: Query<(&DummyVisual, &mut Transform), (Without<MainCamera>, Without<SunLight>, Without<LanternLight>, Without<MillWheel>, Without<DoorPivot>)>,
    mut player_q: Query<(&mut Transform, &mut Visibility), (With<PlayerVisual>, Without<MainCamera>, Without<SunLight>, Without<LanternLight>, Without<MillWheel>, Without<DoorPivot>, Without<DummyVisual>)>,
    mut npc_q: Query<(&NpcVisual, &mut Transform, &mut Visibility), (Without<MainCamera>, Without<SunLight>, Without<LanternLight>, Without<MillWheel>, Without<DoorPivot>, Without<DummyVisual>, Without<PlayerVisual>)>,
    mut horse_q: Query<(&HorseVisual, &mut Transform), (Without<MainCamera>, Without<SunLight>, Without<LanternLight>, Without<MillWheel>, Without<DoorPivot>, Without<DummyVisual>, Without<PlayerVisual>, Without<NpcVisual>)>,
    mut boat_q: Query<&mut Transform, (With<RowboatVisual>, Without<MainCamera>, Without<SunLight>, Without<LanternLight>, Without<MillWheel>, Without<DoorPivot>, Without<DummyVisual>, Without<PlayerVisual>, Without<NpcVisual>, Without<HorseVisual>)>,
    mut flower_q: Query<(&FlowerVisual, &mut Visibility), (Without<PlayerVisual>, Without<NpcVisual>)>,
    mut hammer_q: Query<&mut Visibility, (With<HammerVisual>, Without<PlayerVisual>, Without<NpcVisual>, Without<FlowerVisual>)>,
) {
    let t = time.elapsed_secs();
    let dt = time.delta_secs().min(0.055);
    let a = (world.hour - 6.0) / 24.0 * TAU;
    let alt = a.sin();
    let day = smooth(-0.16, 0.12, alt);
    let rain = world.weather == WeatherKind::Rain;
    let sun_dir = Vec3::new(a.cos() * 0.83, alt, -0.48).normalize();

    if let Some(sh) = shaders {
        if let Some(sky) = sky_mats.get_mut(&sh.sky) {
            sky.sun_dir = sun_dir;
            sky.day = day;
            sky.wet = match world.weather {
                WeatherKind::Clear => 0.0,
                WeatherKind::Mist => 0.42,
                WeatherKind::Rain => 1.0,
            };
            sky.time = t;
        }
        if let Some(water) = water_mats.get_mut(&sh.water) {
            water.sun_dir = sun_dir;
            water.time = world.elapsed;
            water.day = day;
            water.wetness = if rain { 1.0 } else { 0.0 };
            water.ripple_event = Vec3::from_array(world.last_ripple);
        }
    }

    if let Ok((mut st, mut sl)) = sun_q.get_single_mut() {
        let sign = if alt < -0.02 { -85.0 } else { 85.0 };
        st.translation = sun_dir * sign + Vec3::new(8.0, 0.0, -4.0);
        st.look_at(Vec3::new(8.0, 0.0, -4.0), Vec3::Y);
        sl.illuminance = (2_200.0 + day * 24_000.0) * if rain { 0.45 } else { 1.0 };
    }

    if let Ok((mut lt, mut pl)) = lantern_q.get_single_mut() {
        lt.translation = Vec3::new(world.player.x + 0.33, world.player.y + 1.06, world.player.z + 0.1);
        pl.intensity = if world.player.lantern { 14_000.0 } else { 0.0 };
    }

    for mut wt in &mut wheel_q {
        wt.rotation = Quat::from_rotation_y(FRAC_PI_2) * Quat::from_rotation_x(t * 0.17);
    }
    for (dp, mut tr) in &mut door_q {
        if let Some(dr) = world.collision.doors.get(dp.0) {
            tr.rotation = Quat::from_rotation_y(-dr.open * 1.85);
        }
    }
    for (dv, mut tr) in &mut dummy_q {
        if let Some(dm) = world.collision.dummies.get(dv.0) {
            let s = (t * 22.0).sin() * dm.wobble * 0.28;
            tr.rotation = Quat::from_euler(EulerRot::XYZ, dm.dir.cos() * s, 0.0, -dm.dir.sin() * s);
        }
    }
    for mut bt in &mut boat_q {
        bt.translation.y = 0.24 + (t * 0.72).sin() * 0.035;
        bt.rotation = Quat::from_euler(EulerRot::YXZ, 0.15, (t * 0.68).sin() * 0.033, (t * 0.91).sin() * 0.018);
    }

    if let Ok((mut pt, mut pv)) = player_q.get_single_mut() {
        let ride_y = if world.player.horse_idx.is_some() { 0.96 } else { 0.0 };
        pt.translation = Vec3::new(world.player.x, world.player.y + ride_y, world.player.z);
        pt.rotation = Quat::from_rotation_y(world.player.angle);
        *pv = if !world.player.first_person || *state.get() == AppScreen::Cinematic {
            Visibility::Visible
        } else {
            Visibility::Hidden
        };
    }

    for (nv, mut tr, mut vis) in &mut npc_q {
        if let Some(n) = world.npcs.get(nv.0) {
            tr.translation = Vec3::new(n.x, n.y, n.z);
            tr.rotation = Quat::from_rotation_y(n.angle);
            *vis = if n.activity == crate::data::NpcActivity::Sleep && n.path.is_empty() {
                Visibility::Hidden
            } else {
                Visibility::Visible
            };
        }
    }

    for (hv, mut tr) in &mut horse_q {
        if let Some(h) = world.horses.get(hv.0) {
            tr.translation = Vec3::new(h.x, h.y, h.z);
            tr.rotation = Quat::from_rotation_y(h.angle);
        }
    }

    for (fv, mut vis) in &mut flower_q {
        if let Some(f) = world.flowers.get(fv.0) {
            *vis = if f.taken { Visibility::Hidden } else { Visibility::Visible };
        }
    }
    for mut vis in &mut hammer_q {
        *vis = if !world.hammer && world.hammer_quest != 2 {
            Visibility::Visible
        } else {
            Visibility::Hidden
        };
    }

    // Camera tracking (1st-person, 3rd-person with obstacle pullback, Dialogue, Photo, Cinematic)
    if let Ok((mut ct, mut proj, mut fog)) = cam_q.get_single_mut() {
        let p = &world.player;
        let mode = *state.get();
        let (goal, look) = if mode == AppScreen::Cinematic || mode == AppScreen::Menu {
            let u = (t * 0.015 + 0.012) % 1.0;
            let ang = u * TAU;
            (
                Vec3::new(10.0 + ang.cos() * 34.0, 14.0 + (ang * 2.0).sin() * 4.0, -5.0 + ang.sin() * 38.0),
                Vec3::new(4.0 + ang.sin() * 6.0, 3.8, -5.0 + ang.cos() * 8.0),
            )
        } else if mode == AppScreen::Dialogue {
            if let Some(ni) = world.talking {
                let n = &world.npcs[ni];
                let dx = p.x - n.x;
                let dz = p.z - n.z;
                let l = dx.hypot(dz).max(1.0);
                (
                    Vec3::new(n.x + (dx * 2.8 - dz * 0.8) / l, n.y + 1.61, n.z + (dz * 2.8 + dx * 0.8) / l),
                    Vec3::new(n.x, n.y + if n.id == 7 { 1.02 } else { 1.35 }, n.z),
                )
            } else {
                (ct.translation, Vec3::new(p.x, p.y + 1.3, p.z))
            }
        } else if p.first_person && mode != AppScreen::Photo {
            let g = Vec3::new(
                p.x,
                p.y + if p.horse_idx.is_some() { 2.48 } else { 1.61 }
                    + (p.phase * 2.0).sin() * 0.021 * p.speed.min(1.0),
                p.z,
            );
            let l = Vec3::new(
                g.x - p.yaw.sin() * (p.pitch - 0.1).cos() * 8.0,
                g.y - (p.pitch - 0.1).sin() * 8.0,
                g.z - p.yaw.cos() * (p.pitch - 0.1).cos() * 8.0,
            );
            (g, l)
        } else {
            let room = Terrain::inside(&world.buildings, p.x, p.z, 0.25);
            let dist = if mode == AppScreen::Photo {
                world.photo_distance
            } else if room.is_some() {
                2.45
            } else if p.horse_idx.is_some() {
                6.1
            } else {
                5.05
            };
            let ride_h = if p.horse_idx.is_some() { 0.92 } else { 0.0 };
            let mut l = Vec3::new(p.x, p.y + 1.23 + ride_h, p.z);
            let mut g = Vec3::new(
                p.x + p.yaw.sin() * dist * p.pitch.cos(),
                p.y + 1.47 + ride_h + dist * p.pitch.sin(),
                p.z + p.yaw.cos() * dist * p.pitch.cos(),
            );
            if let Some(rm) = room {
                g.y = g.y.min(rm.floor_y + rm.h - 0.52);
            }
            for k in 2..=20 {
                let sample = l.lerp(g, k as f32 / 20.0);
                if world.collision.hit_obstacle_3d(sample.x, sample.y, sample.z, 0.2) {
                    g = l.lerp(g, ((k as f32 - 1.3) / 20.0).max(0.12));
                    break;
                }
            }
            g.y = g.y.max(Terrain::walk(&world.buildings, g.x, g.z, None) + 0.25);
            if mode != AppScreen::Photo {
                l.x -= p.yaw.sin() * 0.72;
                l.z -= p.yaw.cos() * 0.72;
            }
            (g, l)
        };

        let ease = 1.0 - (-dt * if mode == AppScreen::Cinematic { 3.8 } else { 12.0 }).exp();
        ct.translation = ct.translation.lerp(goal, ease);
        if world.shake > 0.001 && mode == AppScreen::Play {
            ct.translation.x += (t * 78.0).sin() * world.shake;
        }
        ct.look_at(look, Vec3::Y);

        if let Projection::Perspective(ref mut pp) = *proj {
            let target_fov = match mode {
                AppScreen::Cinematic => 51.0_f32.to_radians(),
                AppScreen::Dialogue => 43.0_f32.to_radians(),
                AppScreen::Photo => 48.0_f32.to_radians(),
                _ if p.sprint => 65.0_f32.to_radians(),
                _ => 57.0_f32.to_radians(),
            };
            pp.fov = mix(pp.fov, target_fov, 1.0 - (-dt * 5.0).exp());
        }

        fog.falloff = FogFalloff::Exponential {
            density: match world.weather {
                WeatherKind::Mist => 0.012,
                WeatherKind::Rain => 0.0087,
                WeatherKind::Clear => 0.0043,
            },
        };
    }
}
