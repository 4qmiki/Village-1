use bevy::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, States, Default)]
pub enum AppScreen {
    #[default]
    Menu,
    Loading,
    Play,
    Dialogue,
    Paused,
    Photo,
    Cinematic,
    End,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BuildingKind {
    Inn,
    Forge,
    Chapel,
    Mill,
    Hut,
    Stable,
    Bakery,
    Farm,
    Weaver,
    Herbs,
    Lodge,
    Home,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FloorType {
    Wood,
    Stone,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SurfaceKind {
    Grass,
    Dirt,
    Wood,
    Water,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum WeatherKind {
    Clear = 0,
    Mist = 1,
    Rain = 2,
}

impl WeatherKind {
    pub fn next(self) -> Self {
        match self {
            Self::Clear => Self::Mist,
            Self::Mist => Self::Rain,
            Self::Rain => Self::Clear,
        }
    }

    pub fn from_u8(v: u8) -> Self {
        match v % 3 {
            0 => Self::Clear,
            1 => Self::Mist,
            _ => Self::Rain,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::Clear => "Clear skies",
            Self::Mist => "Light mist",
            Self::Rain => "Soft rain",
        }
    }

    pub fn toast_message(self) -> &'static str {
        match self {
            Self::Clear => "The sky clears.",
            Self::Mist => "A soft mist settles over the valley.",
            Self::Rain => "A gentle rain begins to fall.",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum QualityTier {
    Low = 0,
    Medium = 1,
    High = 2,
    Ultra = 3,
}

impl QualityTier {
    pub fn from_u8(v: u8) -> Self {
        match v {
            0 => Self::Low,
            1 => Self::Medium,
            2 => Self::High,
            _ => Self::Ultra,
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::Low => "Low",
            Self::Medium => "Medium",
            Self::High => "High",
            Self::Ultra => "Ultra",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EatKind {
    Bread,
    Stew,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NpcActivity {
    Work,
    Wander,
    Sit,
    Shelter,
    Sleep,
    Talk,
    Flee,
    Guard,
}

#[derive(Debug, Clone)]
pub struct BuildingSpec {
    pub name: &'static str,
    pub kind: BuildingKind,
    pub x: f32,
    pub z: f32,
    pub w: f32,
    pub d: f32,
    pub h: f32,
    pub roof: f32,
    pub enterable: bool,
    pub two_story: bool,
    pub floor_type: FloorType,
    pub sign: Option<&'static str>,
    pub subtitle: Option<&'static str>,
    pub floor_y: f32,
    pub door_w: f32,
    pub door_h: f32,
}

#[derive(Debug, Clone, Copy)]
pub struct PersonSpec {
    pub id: usize,
    pub name: &'static str,
    pub role: &'static str,
    pub x: f32,
    pub z: f32,
    pub color_hex: &'static str,
    pub hello: &'static str,
    pub lore: &'static str,
    pub home: usize,
}

#[derive(Debug, Clone, Copy)]
pub struct HorseSpec {
    pub name: &'static str,
    pub x: f32,
    pub z: f32,
    pub angle: f32,
    pub coat_rgb: [u8; 3],
    pub mane_hex: &'static str,
    pub dapple: bool,
}

pub const PATHS: [[f32; 4]; 8] = [
    [5.0, 48.0, 5.0, -43.0],
    [5.0, 17.0, 19.0, 21.0],
    [5.0, 1.0, -11.0, 0.0],
    [5.0, 1.0, 32.0, -0.5],
    [5.0, -17.0, 35.0, -15.0],
    [30.0, -15.0, 37.0, -30.0],
    [6.0, 25.0, 31.0, 34.0],
    [5.0, -28.0, -3.0, -16.0],
];

pub const MEREBELL_SPOTS: [[f32; 2]; 6] = [
    [5.35, 19.0],
    [3.4, 8.0],
    [1.1, -7.0],
    [-4.5, -5.0],
    [12.0, -23.0],
    [24.5, 23.0],
];

pub const DUMMY_SPOTS: [[f32; 2]; 2] = [[11.6, -13.4], [13.7, -12.5]];

pub const VISTA_NAMES: [&str; 3] = [
    "Lakeside Overlook",
    "Evening on the Mere",
    "Morning in the Valley",
];

pub const CONTROL_LIST: [(&str, &str); 20] = [
    ("Move", "W A S D"),
    ("Look around", "Mouse"),
    ("Sprint", "Shift"),
    ("Jump", "Space"),
    ("Interact / reel in", "E"),
    ("Field journal", "J"),
    ("First / third person", "V"),
    ("Carry lantern", "F"),
    ("Eat meal / snack", "G"),
    ("Draw / sheathe sword", "Q"),
    ("Sword combo strike", "X / Click"),
    ("Heavy sword cleave", "H"),
    ("Block / guard", "Z"),
    ("Mount / dismount horse", "E"),
    ("Cinematic tour", "C"),
    ("Photo mode", "P"),
    ("Time speed", "T"),
    ("Change weather", "R"),
    ("Show frame rate", "F3"),
    ("Pause / return", "Esc"),
];

pub const PEOPLE: [PersonSpec; 10] = [
    PersonSpec {
        id: 0,
        name: "Elin",
        role: "Innkeeper",
        x: 5.2,
        z: 20.5,
        color_hex: "#92714e",
        hello: "The Heron has kept a fire for travelers for a hundred winters. I mean to keep it for a hundred more.",
        lore: "My grandmother built the first hearth with stones from the old bridge. Listen to the fire, and you might hear the river.",
        home: 0,
    },
    PersonSpec {
        id: 1,
        name: "Rowan",
        role: "Blacksmith",
        x: 20.2,
        z: 0.2,
        color_hex: "#695647",
        hello: "A good tool remembers its maker. Pity my best hammer forgot the way home.",
        lore: "I forge the bell clapper anew each spring. That note you hear at dusk? That is my small part of Hollowmere.",
        home: 1,
    },
    PersonSpec {
        id: 2,
        name: "Bram",
        role: "Fisherman",
        x: -7.1,
        z: -1.0,
        color_hex: "#73877b",
        hello: "Soft steps, traveler. Even the lake has ears.",
        lore: "My father called this water the sky below. Never caught the moon, though. You can try your luck at the end of the dock.",
        home: 4,
    },
    PersonSpec {
        id: 3,
        name: "Alys",
        role: "Herbalist",
        x: 31.0,
        z: 8.0,
        color_hex: "#75825b",
        hello: "There is balm for most troubles growing right beneath our boots.",
        lore: "The little gold flowers by the paths are merebells. Gather one, and carry a little of the valley with you.",
        home: 9,
    },
    PersonSpec {
        id: 4,
        name: "Oswin",
        role: "Village guard",
        x: 9.0,
        z: -12.0,
        color_hex: "#647b83",
        hello: "Peaceful road today. I like my boots muddy and my sword clean.",
        lore: "The old watchtower never saw a siege. These days I guard the geese from the baker, or perhaps the other way around.",
        home: 10,
    },
    PersonSpec {
        id: 5,
        name: "Brother Alden",
        role: "Chapel keeper",
        x: 6.0,
        z: -24.0,
        color_hex: "#5e6557",
        hello: "The chapel door stands open to folk of every road.",
        lore: "Our bell once lay beneath the Mere. On still nights, some say its echo is still down there.",
        home: 2,
    },
    PersonSpec {
        id: 6,
        name: "Mara",
        role: "Merchant",
        x: 12.5,
        z: 3.6,
        color_hex: "#986053",
        hello: "Welcome to my corner of the world. The view is free today.",
        lore: "I traded my wagon for this stall after one look at the mountains. My sisters say it was my best bargain.",
        home: 6,
    },
    PersonSpec {
        id: 7,
        name: "Pip",
        role: "Miller's child",
        x: -1.0,
        z: -10.5,
        color_hex: "#9c9969",
        hello: "I know where the silver fish live. I am sworn to secrecy. Mostly.",
        lore: "The mill wheel has thirty-two paddles. I counted thirty-three once, but I was running in circles.",
        home: 3,
    },
    PersonSpec {
        id: 8,
        name: "Edric",
        role: "Farmer",
        x: 34.0,
        z: -28.0,
        color_hex: "#8f885a",
        hello: "Good earth, kind rain, and a second helping. That is a life.",
        lore: "The northern field grows the sweetest carrots. My wife says it is the soil. I say it is the songs.",
        home: 7,
    },
    PersonSpec {
        id: 9,
        name: "Nessa",
        role: "Weaver",
        x: 7.5,
        z: 31.4,
        color_hex: "#8a7181",
        hello: "Every thread has a place, even the wandering ones.",
        lore: "I dye our blue wool with woad by the water. Look at the lake at dusk and you will see where I learned the color.",
        home: 8,
    },
];

pub const HORSES: [HorseSpec; 3] = [
    HorseSpec {
        name: "Black Friesian",
        x: 2.4,
        z: 25.8,
        angle: 0.4,
        coat_rgb: [36, 34, 36],
        mane_hex: "#1b1918",
        dapple: false,
    },
    HorseSpec {
        name: "Dapple-Grey Courser",
        x: 12.6,
        z: 23.2,
        angle: -1.1,
        coat_rgb: [174, 174, 168],
        mane_hex: "#d6d3c8",
        dapple: true,
    },
    HorseSpec {
        name: "Chestnut Warmblood",
        x: 24.5,
        z: 31.8,
        angle: 2.4,
        coat_rgb: [124, 66, 38],
        mane_hex: "#3a2416",
        dapple: false,
    },
];

pub fn build_buildings() -> Vec<BuildingSpec> {
    let mut list = vec![
        BuildingSpec {
            name: "The Gilded Heron",
            kind: BuildingKind::Inn,
            x: 18.0, z: 16.0, w: 10.0, d: 7.0, h: 5.3, roof: 3.7,
            enterable: true, two_story: false, floor_type: FloorType::Wood,
            sign: Some("TAVERN & INN"), subtitle: Some("Tavern & Restaurant"),
            floor_y: 0.0, door_w: 1.76, door_h: 2.38,
        },
        BuildingSpec {
            name: "Rowan's Forge",
            kind: BuildingKind::Forge,
            x: 24.0, z: -4.0, w: 7.5, d: 6.0, h: 3.4, roof: 2.7,
            enterable: true, two_story: false, floor_type: FloorType::Stone,
            sign: Some("BLACKSMITH"), subtitle: Some("Smithy & Tool Shop"),
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "Saint Mere Chapel",
            kind: BuildingKind::Chapel,
            x: 7.0, z: -32.0, w: 6.8, d: 10.5, h: 5.0, roof: 4.0,
            enterable: true, two_story: false, floor_type: FloorType::Stone,
            sign: Some("CHAPEL"), subtitle: Some("Village Sanctuary"),
            floor_y: 0.0, door_w: 1.76, door_h: 2.55,
        },
        BuildingSpec {
            name: "The Old Mill",
            kind: BuildingKind::Mill,
            x: -3.7, z: -21.0, w: 6.7, d: 6.4, h: 5.6, roof: 3.3,
            enterable: false, two_story: false, floor_type: FloorType::Wood,
            sign: None, subtitle: None,
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "Fisherman's Rest",
            kind: BuildingKind::Hut,
            x: -3.0, z: 8.0, w: 5.2, d: 4.7, h: 2.9, roof: 2.7,
            enterable: false, two_story: false, floor_type: FloorType::Wood,
            sign: None, subtitle: None,
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "Hillgate Stable",
            kind: BuildingKind::Stable,
            x: 31.0, z: 29.0, w: 8.4, d: 6.7, h: 3.4, roof: 3.2,
            enterable: false, two_story: false, floor_type: FloorType::Wood,
            sign: None, subtitle: None,
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "Mara's Bakery & Goods",
            kind: BuildingKind::Bakery,
            x: 33.0, z: -20.0, w: 6.4, d: 5.8, h: 3.8, roof: 3.2,
            enterable: true, two_story: false, floor_type: FloorType::Wood,
            sign: Some("BAKERY"), subtitle: Some("Bakery & Provisions"),
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "Amberfield Farm",
            kind: BuildingKind::Farm,
            x: 42.0, z: -33.0, w: 7.2, d: 6.0, h: 3.4, roof: 3.4,
            enterable: false, two_story: false, floor_type: FloorType::Wood,
            sign: None, subtitle: None,
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "The Weavers' House",
            kind: BuildingKind::Weaver,
            x: 10.0, z: 39.0, w: 6.7, d: 5.4, h: 4.3, roof: 3.4,
            enterable: true, two_story: false, floor_type: FloorType::Wood,
            sign: Some("WEAVER SHOP"), subtitle: Some("Textiles & Dyes"),
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "Hearthroot Apothecary",
            kind: BuildingKind::Herbs,
            x: 38.0, z: 7.0, w: 6.4, d: 5.8, h: 3.6, roof: 3.1,
            enterable: true, two_story: false, floor_type: FloorType::Wood,
            sign: Some("APOTHECARY"), subtitle: Some("Herbs & Remedies"),
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "Northwatch Lodge",
            kind: BuildingKind::Lodge,
            x: 13.0, z: -47.0, w: 6.7, d: 5.7, h: 4.2, roof: 3.4,
            enterable: false, two_story: false, floor_type: FloorType::Wood,
            sign: None, subtitle: None,
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
        BuildingSpec {
            name: "Traveler's Rest",
            kind: BuildingKind::Home,
            x: -3.5, z: 23.0, w: 8.4, d: 6.8, h: 6.2, roof: 3.5,
            enterable: true, two_story: true, floor_type: FloorType::Wood,
            sign: Some("HOME"), subtitle: Some("Your Two-Story Manor"),
            floor_y: 0.0, door_w: 1.6, door_h: 2.38,
        },
    ];
    for b in &mut list {
        if b.enterable {
            let mut max_h = f32::NEG_INFINITY;
            for dx in [-b.w * 0.5, 0.0, b.w * 0.5] {
                for dz in [-b.d * 0.5, 0.0, b.d * 0.5] {
                    max_h = max_h.max(crate::terrain::Terrain::height(b.x + dx, b.z + dz));
                }
            }
            b.floor_y = max_h + 0.26;
        }
    }
    list
}

pub fn hex_to_color(hex: &str) -> Color {
    let s = hex.trim_start_matches('#');
    if s.len() == 6 {
        let r = u8::from_str_radix(&s[0..2], 16).unwrap_or(128);
        let g = u8::from_str_radix(&s[2..4], 16).unwrap_or(128);
        let b = u8::from_str_radix(&s[4..6], 16).unwrap_or(128);
        Color::srgb_u8(r, g, b)
    } else {
        Color::srgb(0.6, 0.6, 0.5)
    }
}
