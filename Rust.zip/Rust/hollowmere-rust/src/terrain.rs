use crate::data::{BuildingSpec, FloorType, SurfaceKind, PATHS};
use crate::math::{clamp, dist_seg, fbm, mix, noise, smooth};

#[derive(Debug, Clone, Copy)]
pub struct StairInfo {
    pub x0: f32,
    pub x1: f32,
    pub z_bot: f32,
    pub z_top: f32,
    pub y2: f32,
}

pub struct Terrain;

impl Terrain {
    pub fn lake(x: f32, z: f32) -> f32 {
        ((x + 53.0) / 46.0).hypot((z + 18.0) / 54.0) + (noise(x * 0.07, z * 0.07) - 0.5) * 0.035
    }

    pub fn height(x: f32, z: f32) -> f32 {
        let l = Self::lake(x, z);
        let n = fbm(x * 0.037 + 7.0, z * 0.037);
        let f = clamp(((x - 15.0).abs() * 0.92).max(z.abs()) - 46.0, 0.0, 58.0) / 58.0;
        let base = 1.45 + (n - 0.5) * 0.9 + f * f * (16.0 + fbm(x * 0.015, z * 0.015) * 35.0);
        if l < 1.12 {
            mix(-3.3 + n * 0.3, base, smooth(0.82, 1.12, l))
        } else {
            base
        }
    }

    pub fn path(x: f32, z: f32) -> f32 {
        let mut d = 100.0f32;
        for p in PATHS {
            d = d.min(dist_seg(x, z, p[0], p[1], p[2], p[3]));
        }
        d
    }

    pub fn dock(x: f32, z: f32) -> bool {
        x > -18.6 && x < -3.9 && z > -2.25 && z < 0.55
    }

    pub fn inside<'a>(buildings: &'a [BuildingSpec], x: f32, z: f32, pad: f32) -> Option<&'a BuildingSpec> {
        buildings.iter().find(|b| {
            b.enterable
                && (x - b.x).abs() < b.w * 0.5 + pad
                && (z - b.z).abs() < b.d * 0.5 + pad
        })
    }

    pub fn stair_info(b: &BuildingSpec) -> StairInfo {
        let hw = b.w * 0.5;
        StairInfo {
            x0: b.x - hw + 0.22,
            x1: b.x - hw + 1.58,
            z_bot: b.z + 1.55,
            z_top: b.z - 2.05,
            y2: b.floor_y + 3.05,
        }
    }

    pub fn walk(buildings: &[BuildingSpec], x: f32, z: f32, cur_y: Option<f32>) -> f32 {
        for b in buildings {
            if !b.enterable {
                continue;
            }
            let hw = b.w * 0.5;
            let hd = b.d * 0.5;
            let front = b.z + hd;
            if (x - b.x).abs() <= hw + 0.08 && (z - b.z).abs() <= hd + 0.08 {
                if b.two_story {
                    let st = Self::stair_info(b);
                    let on_stairs = x >= st.x0 - 0.15
                        && x <= st.x1 + 0.15
                        && z <= st.z_bot + 0.25
                        && z >= st.z_top - 0.25;
                    if on_stairs {
                        let t = clamp((st.z_bot - z) / (st.z_bot - st.z_top), 0.0, 1.0);
                        return mix(b.floor_y, st.y2, t);
                    }
                    if let Some(y) = cur_y {
                        if y > b.floor_y + 1.65 {
                            return st.y2;
                        }
                    }
                }
                return b.floor_y;
            }
            if (x - b.x).abs() <= b.door_w * 0.5 + 0.42 && z > front && z < front + 1.15 {
                let t = clamp((z - front) / 1.15, 0.0, 1.0);
                return mix(b.floor_y, Self::height(x, z).max(0.04), t);
            }
        }
        if Self::dock(x, z) {
            1.52
        } else {
            Self::height(x, z).max(0.04)
        }
    }

    pub fn surface(buildings: &[BuildingSpec], x: f32, z: f32) -> SurfaceKind {
        if let Some(b) = Self::inside(buildings, x, z, 0.12) {
            return match b.floor_type {
                FloorType::Stone => SurfaceKind::Dirt,
                FloorType::Wood => SurfaceKind::Wood,
            };
        }
        if Self::dock(x, z) {
            SurfaceKind::Wood
        } else if Self::height(x, z) < 0.35 {
            SurfaceKind::Water
        } else if Self::path(x, z) < 2.0 {
            SurfaceKind::Dirt
        } else {
            SurfaceKind::Grass
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::data::build_buildings;

    #[test]
    fn dock_height_and_surface() {
        let buildings = build_buildings();
        assert!(Terrain::dock(-12.0, -0.8));
        assert!((Terrain::walk(&buildings, -12.0, -0.8, None) - 1.52).abs() < 1e-5);
        assert_eq!(Terrain::surface(&buildings, -12.0, -0.8), SurfaceKind::Wood);
    }

    #[test]
    fn two_story_staircase_ascends_smoothly() {
        let buildings = build_buildings();
        let home = buildings.iter().find(|b| b.two_story).expect("Traveler's Rest exists");
        let st = Terrain::stair_info(home);
        let mid_x = (st.x0 + st.x1) * 0.5;
        let y_bot = Terrain::walk(&buildings, mid_x, st.z_bot, None);
        let y_mid = Terrain::walk(&buildings, mid_x, (st.z_bot + st.z_top) * 0.5, Some(y_bot));
        let y_top = Terrain::walk(&buildings, mid_x, st.z_top, Some(y_mid));
        assert!(y_mid > y_bot + 1.0);
        assert!((y_top - st.y2).abs() < 0.05);
    }
}
