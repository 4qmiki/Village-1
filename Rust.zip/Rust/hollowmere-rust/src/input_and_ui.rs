use std::f32::consts::FRAC_PI_4;

use bevy::input::mouse::{MouseMotion, MouseWheel};
use bevy::input::touch::Touches;
use bevy::prelude::*;

use crate::data::{AppScreen, EatKind, VISTA_NAMES};
use crate::math::fmt_time;
use crate::terrain::Terrain;
use crate::world_state::{GameSettings, HollowmereWorld};

#[derive(Resource, Default)]
pub struct TouchStickState {
    pub x: f32,
    pub y: f32,
    pub stick_touch_id: Option<u64>,
    pub look_touch_id: Option<u64>,
    pub last_look_pos: Vec2,
}

#[derive(Component)]
pub struct TitleScreenRoot;

#[derive(Component)]
pub struct HudRoot;

#[derive(Component)]
pub struct HudClockText;

#[derive(Component)]
pub struct HudCompassText;

#[derive(Component)]
pub struct HudObjectiveText;

#[derive(Component)]
pub struct HudRenownText;

#[derive(Component)]
pub struct HudInteractText;

#[derive(Component)]
pub struct HudToastText;

#[derive(Component)]
pub struct HudSwordLabel;

#[derive(Component)]
pub struct HudViewLabel;

#[derive(Component)]
pub struct FishUiRoot;

#[derive(Component)]
pub struct FishPinNode;

#[derive(Component)]
pub struct DialogueRoot;

#[derive(Component)]
pub struct DialogueSpeakerText;

#[derive(Component)]
pub struct DialogueBodyText;

#[derive(Component)]
pub enum UiActionButton {
    StartVillage,
    ToggleSword,
    ToggleView,
    Interact,
    Jump,
    SwordSlash,
    SwordHeavy,
    SwordBlock,
    Pause,
    Resume,
    NextVista,
    PrevVista,
    CloseDialogue,
    AcceptOrAdvanceQuest,
}

pub fn setup_ui(mut commands: Commands) {
    // === Title Screen ===
    commands
        .spawn((
            Node {
                width: Val::Percent(100.0),
                height: Val::Percent(100.0),
                flex_direction: FlexDirection::Column,
                justify_content: JustifyContent::SpaceBetween,
                padding: UiRect::all(Val::Px(32.0)),
                ..default()
            },
            BackgroundColor(Color::srgba(0.06, 0.11, 0.10, 0.72)),
            TitleScreenRoot,
        ))
        .with_children(|root| {
            // Top bar
            root.spawn(Node {
                width: Val::Percent(100.0),
                justify_content: JustifyContent::SpaceBetween,
                align_items: AlignItems::Center,
                ..default()
            })
            .with_children(|top| {
                top.spawn((
                    Text::new("HOLLOWMERE"),
                    TextFont { font_size: 18.0, ..default() },
                    TextColor(Color::srgb_u8(243, 239, 226)),
                ));
                top.spawn((
                    Text::new("Overview   ·   Field journal   ·   Settings"),
                    TextFont { font_size: 13.0, ..default() },
                    TextColor(Color::srgb_u8(228, 229, 217)),
                ));
            });

            // Hero block
            root.spawn(Node {
                flex_direction: FlexDirection::Column,
                row_gap: Val::Px(12.0),
                max_width: Val::Px(640.0),
                ..default()
            })
            .with_children(|hero| {
                hero.spawn((
                    Text::new("A MEDIEVAL EXPLORATION"),
                    TextFont { font_size: 12.0, ..default() },
                    TextColor(Color::srgb_u8(219, 195, 144)),
                ));
                hero.spawn((
                    Text::new("Hollowmere"),
                    TextFont { font_size: 68.0, ..default() },
                    TextColor(Color::srgb_u8(244, 240, 225)),
                ));
                hero.spawn((
                    Text::new("A living medieval village, nestled between misty peaks and the still waters of the Mere."),
                    TextFont { font_size: 16.0, ..default() },
                    TextColor(Color::srgb_u8(224, 226, 214)),
                ));
                hero.spawn((
                    Button,
                    Node {
                        margin: UiRect::top(Val::Px(16.0)),
                        padding: UiRect::axes(Val::Px(26.0), Val::Px(14.0)),
                        align_self: AlignSelf::FlexStart,
                        ..default()
                    },
                    BackgroundColor(Color::srgb_u8(212, 186, 128)),
                    UiActionButton::StartVillage,
                ))
                .with_children(|b| {
                    b.spawn((
                        Text::new("Enter the village  ->"),
                        TextFont { font_size: 15.0, ..default() },
                        TextColor(Color::srgb_u8(40, 43, 32)),
                    ));
                });
            });

            // Footer vista selector
            root.spawn(Node {
                width: Val::Percent(100.0),
                justify_content: JustifyContent::SpaceBetween,
                align_items: AlignItems::Center,
                ..default()
            })
            .with_children(|foot| {
                foot.spawn((
                    Text::new(format!("VILLAGE VISTA: {}", VISTA_NAMES[0])),
                    TextFont { font_size: 14.0, ..default() },
                    TextColor(Color::srgb_u8(238, 236, 222)),
                ));
                foot.spawn(Node { column_gap: Val::Px(10.0), ..default() }).with_children(|row| {
                    for (label, act) in [("<", UiActionButton::PrevVista), (">", UiActionButton::NextVista)] {
                        row.spawn((
                            Button,
                            Node {
                                padding: UiRect::axes(Val::Px(12.0), Val::Px(6.0)),
                                ..default()
                            },
                            BackgroundColor(Color::srgba(0.12, 0.18, 0.16, 0.75)),
                            act,
                        ))
                        .with_children(|b| {
                            b.spawn((Text::new(label), TextFont { font_size: 14.0, ..default() }, TextColor(Color::WHITE)));
                        });
                    }
                });
            });
        });

    // === Gameplay HUD + Mobile Touch Controls ===
    commands
        .spawn((
            Node {
                width: Val::Percent(100.0),
                height: Val::Percent(100.0),
                position_type: PositionType::Absolute,
                ..default()
            },
            Visibility::Hidden,
            HudRoot,
        ))
        .with_children(|hud| {
            // Top bar: Brand, Compass, Clock & Quick Toggles
            hud.spawn(Node {
                position_type: PositionType::Absolute,
                top: Val::Px(16.0),
                left: Val::Px(20.0),
                right: Val::Px(20.0),
                justify_content: JustifyContent::SpaceBetween,
                align_items: AlignItems::Center,
                ..default()
            })
            .with_children(|top| {
                top.spawn((
                    Text::new("HOLLOWMERE"),
                    TextFont { font_size: 15.0, ..default() },
                    TextColor(Color::srgb_u8(243, 239, 226)),
                ));
                top.spawn((
                    Text::new("NW   N   NE"),
                    TextFont { font_size: 13.0, ..default() },
                    TextColor(Color::srgb_u8(249, 227, 173)),
                    HudCompassText,
                ));
                top.spawn(Node { column_gap: Val::Px(8.0), align_items: AlignItems::Center, ..default() })
                    .with_children(|tools| {
                        tools.spawn((
                            Text::new("17:30"),
                            TextFont { font_size: 13.0, ..default() },
                            TextColor(Color::srgb_u8(243, 235, 209)),
                            HudClockText,
                        ));
                        spawn_hud_btn(tools, "SWORD", UiActionButton::ToggleSword, Some(HudSwordLabel));
                        spawn_hud_btn(tools, "3RD", UiActionButton::ToggleView, Some(HudViewLabel));
                        spawn_hud_btn(tools, "PAUSE", UiActionButton::Pause, None::<HudViewLabel>);
                    });
            });

            // Current Objective
            hud.spawn((
                Node {
                    position_type: PositionType::Absolute,
                    top: Val::Px(64.0),
                    left: Val::Px(20.0),
                    padding: UiRect::axes(Val::Px(12.0), Val::Px(6.0)),
                    ..default()
                },
                BackgroundColor(Color::srgba(0.09, 0.15, 0.12, 0.68)),
            ))
            .with_children(|obj| {
                obj.spawn((
                    Text::new("Meet Elin, the innkeeper"),
                    TextFont { font_size: 15.0, ..default() },
                    TextColor(Color::srgb_u8(243, 239, 226)),
                    HudObjectiveText,
                ));
            });

            // Renown Counter (bottom-left)
            hud.spawn((
                Node {
                    position_type: PositionType::Absolute,
                    bottom: Val::Px(18.0),
                    left: Val::Px(20.0),
                    ..default()
                },
            ))
            .with_children(|r| {
                r.spawn((
                    Text::new("0 RENOWN"),
                    TextFont { font_size: 15.0, ..default() },
                    TextColor(Color::srgb_u8(216, 189, 129)),
                    HudRenownText,
                ));
            });

            // Center Toast & Interaction Prompt
            hud.spawn((
                Node {
                    position_type: PositionType::Absolute,
                    top: Val::Percent(14.0),
                    left: Val::Percent(25.0),
                    right: Val::Percent(25.0),
                    justify_content: JustifyContent::Center,
                    ..default()
                },
            ))
            .with_children(|t| {
                t.spawn((
                    Text::new(""),
                    TextFont { font_size: 14.0, ..default() },
                    TextColor(Color::srgb_u8(242, 234, 213)),
                    HudToastText,
                ));
            });

            hud.spawn((
                Button,
                Node {
                    position_type: PositionType::Absolute,
                    bottom: Val::Percent(16.0),
                    left: Val::Percent(35.0),
                    right: Val::Percent(35.0),
                    justify_content: JustifyContent::Center,
                    padding: UiRect::axes(Val::Px(14.0), Val::Px(8.0)),
                    ..default()
                },
                BackgroundColor(Color::srgba(0.09, 0.14, 0.12, 0.78)),
                UiActionButton::Interact,
            ))
            .with_children(|b| {
                b.spawn((
                    Text::new(""),
                    TextFont { font_size: 14.0, ..default() },
                    TextColor(Color::srgb_u8(244, 236, 207)),
                    HudInteractText,
                ));
            });

            // Touch Action Buttons (bottom-right: Slash, Heavy, Guard, Jump, Interact)
            hud.spawn(Node {
                position_type: PositionType::Absolute,
                right: Val::Px(18.0),
                bottom: Val::Px(28.0),
                column_gap: Val::Px(8.0),
                ..default()
            })
            .with_children(|tb| {
                spawn_touch_btn(tb, "SLASH", UiActionButton::SwordSlash);
                spawn_touch_btn(tb, "HEAVY", UiActionButton::SwordHeavy);
                spawn_touch_btn(tb, "GUARD", UiActionButton::SwordBlock);
                spawn_touch_btn(tb, "JUMP", UiActionButton::Jump);
                spawn_touch_btn(tb, "USE", UiActionButton::Interact);
            });

            // Fishing Minigame Bar
            hud.spawn((
                Node {
                    position_type: PositionType::Absolute,
                    top: Val::Percent(64.0),
                    left: Val::Percent(30.0),
                    right: Val::Percent(30.0),
                    padding: UiRect::all(Val::Px(14.0)),
                    flex_direction: FlexDirection::Column,
                    row_gap: Val::Px(8.0),
                    ..default()
                },
                BackgroundColor(Color::srgba(0.09, 0.15, 0.12, 0.92)),
                Visibility::Hidden,
                FishUiRoot,
            ))
            .with_children(|f| {
                f.spawn((
                    Text::new("A tug on the line — Press E or tap USE in the golden zone"),
                    TextFont { font_size: 14.0, ..default() },
                    TextColor(Color::srgb_u8(243, 213, 156)),
                ));
                f.spawn((
                    Node {
                        width: Val::Percent(100.0),
                        height: Val::Px(10.0),
                        ..default()
                    },
                    BackgroundColor(Color::srgba(0.82, 0.82, 0.67, 0.28)),
                ))
                .with_children(|track| {
                    track.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: Val::Percent(55.0),
                            width: Val::Percent(26.0),
                            height: Val::Percent(100.0),
                            ..default()
                        },
                        BackgroundColor(Color::srgb_u8(185, 187, 125)),
                    ));
                    track.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: Val::Percent(50.0),
                            width: Val::Px(4.0),
                            height: Val::Px(16.0),
                            ..default()
                        },
                        BackgroundColor(Color::srgb_u8(243, 213, 156)),
                        FishPinNode,
                    ));
                });
            });
        });

    // === Dialogue Box ===
    commands
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                bottom: Val::Px(24.0),
                left: Val::Percent(12.0),
                right: Val::Percent(12.0),
                padding: UiRect::all(Val::Px(22.0)),
                flex_direction: FlexDirection::Column,
                row_gap: Val::Px(10.0),
                ..default()
            },
            BackgroundColor(Color::srgb_u8(220, 210, 180)),
            Visibility::Hidden,
            DialogueRoot,
        ))
        .with_children(|dlg| {
            dlg.spawn((
                Text::new("Elin — Innkeeper"),
                TextFont { font_size: 20.0, ..default() },
                TextColor(Color::srgb_u8(53, 62, 48)),
                DialogueSpeakerText,
            ));
            dlg.spawn((
                Text::new(""),
                TextFont { font_size: 15.0, ..default() },
                TextColor(Color::srgb_u8(53, 62, 48)),
                DialogueBodyText,
            ));
            dlg.spawn(Node { column_gap: Val::Px(12.0), ..default() }).with_children(|row| {
                row.spawn((
                    Button,
                    Node { padding: UiRect::axes(Val::Px(14.0), Val::Px(8.0)), ..default() },
                    BackgroundColor(Color::srgba(0.28, 0.34, 0.24, 0.25)),
                    UiActionButton::AcceptOrAdvanceQuest,
                ))
                .with_children(|b| {
                    b.spawn((Text::new("Ask about village favor"), TextFont { font_size: 13.0, ..default() }, TextColor(Color::srgb_u8(45, 55, 40))));
                });
                row.spawn((
                    Button,
                    Node { padding: UiRect::axes(Val::Px(14.0), Val::Px(8.0)), ..default() },
                    BackgroundColor(Color::srgba(0.28, 0.34, 0.24, 0.15)),
                    UiActionButton::CloseDialogue,
                ))
                .with_children(|b| {
                    b.spawn((Text::new("Farewell"), TextFont { font_size: 13.0, ..default() }, TextColor(Color::srgb_u8(45, 55, 40))));
                });
            });
        });
}

fn spawn_hud_btn<L: Component>(
    parent: &mut ChildBuilder,
    label: &str,
    action: UiActionButton,
    label_marker: Option<L>,
) {
    parent
        .spawn((
            Button,
            Node {
                padding: UiRect::axes(Val::Px(10.0), Val::Px(5.0)),
                ..default()
            },
            BackgroundColor(Color::srgba(0.08, 0.14, 0.12, 0.72)),
            action,
        ))
        .with_children(|b| {
            let mut e = b.spawn((
                Text::new(label),
                TextFont { font_size: 11.0, ..default() },
                TextColor(Color::srgb_u8(230, 228, 214)),
            ));
            if let Some(m) = label_marker {
                e.insert(m);
            }
        });
}

fn spawn_touch_btn(parent: &mut ChildBuilder, label: &str, action: UiActionButton) {
    parent
        .spawn((
            Button,
            Node {
                width: Val::Px(52.0),
                height: Val::Px(52.0),
                justify_content: JustifyContent::Center,
                align_items: AlignItems::Center,
                ..default()
            },
            BackgroundColor(Color::srgba(0.11, 0.19, 0.15, 0.78)),
            action,
        ))
        .with_children(|b| {
            b.spawn((
                Text::new(label),
                TextFont { font_size: 10.0, ..default() },
                TextColor(Color::srgb_u8(243, 239, 226)),
            ));
        });
}

#[allow(clippy::too_many_arguments)]
pub fn handle_input_and_step(
    time: Res<Time>,
    keys: Res<ButtonInput<KeyCode>>,
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    mut mouse_motion: EventReader<MouseMotion>,
    mut mouse_wheel: EventReader<MouseWheel>,
    touches: Res<Touches>,
    windows: Query<&Window>,
    state: Res<State<AppScreen>>,
    mut next_state: ResMut<NextState<AppScreen>>,
    mut stick: ResMut<TouchStickState>,
    mut world: ResMut<HollowmereWorld>,
) {
    let dt = time.delta_secs().min(0.055);
    let cur = *state.get();

    // Touch controls: left 35% of screen = virtual movement joystick, right 65% = look swipe
    if let Ok(win) = windows.get_single() {
        let split_x = win.width() * 0.35;
        let stick_center = Vec2::new(78.0, win.height() - 96.0);
        for touch in touches.iter_just_pressed() {
            let pos = touch.position();
            if pos.x < split_x && stick.stick_touch_id.is_none() {
                stick.stick_touch_id = Some(touch.id());
            } else if pos.x >= split_x && stick.look_touch_id.is_none() {
                stick.look_touch_id = Some(touch.id());
                stick.last_look_pos = pos;
            }
        }
        for touch in touches.iter() {
            if Some(touch.id()) == stick.stick_touch_id {
                let d = (touch.position() - stick_center) / 48.0;
                let l = d.length().max(1.0);
                stick.x = d.x / l;
                stick.y = d.y / l;
            } else if Some(touch.id()) == stick.look_touch_id {
                let delta = touch.position() - stick.last_look_pos;
                stick.last_look_pos = touch.position();
                if matches!(cur, AppScreen::Play | AppScreen::Photo) {
                    world.look_by(delta.x, delta.y);
                }
            }
        }
        for touch in touches.iter_just_released().chain(touches.iter_just_canceled()) {
            if Some(touch.id()) == stick.stick_touch_id {
                stick.stick_touch_id = None;
                stick.x = 0.0;
                stick.y = 0.0;
            }
            if Some(touch.id()) == stick.look_touch_id {
                stick.look_touch_id = None;
            }
        }
    }

    // Mouse look & Photo zoom
    if matches!(cur, AppScreen::Play | AppScreen::Photo) {
        for ev in mouse_motion.read() {
            if mouse_buttons.pressed(MouseButton::Left) || mouse_buttons.pressed(MouseButton::Right) {
                world.look_by(ev.delta.x, ev.delta.y);
            }
        }
        if cur == AppScreen::Photo {
            for ev in mouse_wheel.read() {
                world.photo_distance = (world.photo_distance - ev.y * 0.45).clamp(2.0, 22.0);
            }
        }
    }

    if keys.just_pressed(KeyCode::Escape) {
        match cur {
            AppScreen::Dialogue => {
                world.talking = None;
                next_state.set(AppScreen::Play);
            }
            AppScreen::Photo | AppScreen::Cinematic | AppScreen::Paused => next_state.set(AppScreen::Play),
            AppScreen::Play => next_state.set(AppScreen::Paused),
            _ => {}
        }
        return;
    }

    if cur != AppScreen::Play {
        if cur == AppScreen::Cinematic {
            world.step_simulation(dt, 0.0, 0.0, false, false);
        }
        return;
    }

    // Hotkeys matching CONTROL_LIST
    if keys.just_pressed(KeyCode::KeyE) {
        if world.interact().is_some() {
            next_state.set(AppScreen::Dialogue);
        }
    }
    if keys.just_pressed(KeyCode::Space) {
        world.jump();
    }
    if keys.just_pressed(KeyCode::KeyF) {
        world.player.lantern = !world.player.lantern;
        world.toast(if world.player.lantern { "Lantern lit." } else { "Lantern extinguished." }, 1.8);
    }
    if keys.just_pressed(KeyCode::KeyG) {
        let in_inn = Terrain::inside(&world.buildings, world.player.x, world.player.z, 0.0)
            .is_some_and(|b| b.kind == crate::data::BuildingKind::Inn);
        world.eat(if in_inn { EatKind::Stew } else { EatKind::Bread }, None);
    }
    if keys.just_pressed(KeyCode::KeyQ) {
        world.toggle_sword();
    }
    if keys.just_pressed(KeyCode::KeyX) {
        world.attack(false);
    }
    if keys.just_pressed(KeyCode::KeyH) {
        world.attack(true);
    }
    if keys.just_pressed(KeyCode::KeyV) {
        world.player.first_person = !world.player.first_person;
        world.toast(if world.player.first_person { "First-person view" } else { "Third-person view" }, 1.4);
    }
    if keys.just_pressed(KeyCode::KeyT) {
        world.rate = if world.rate == 1.0 { 25.0 } else if world.rate == 25.0 { 0.0 } else { 1.0 };
        world.toast(
            if world.rate == 0.0 {
                "Time is paused."
            } else if world.rate == 25.0 {
                "Time passes 25 times faster."
            } else {
                "Time returns to its natural pace."
            },
            2.2,
        );
    }
    if keys.just_pressed(KeyCode::KeyR) {
        world.weather = world.weather.next();
        let msg = world.weather.toast_message();
        world.toast(msg, 2.2);
    }
    if keys.just_pressed(KeyCode::KeyP) {
        next_state.set(AppScreen::Photo);
    }
    if keys.just_pressed(KeyCode::KeyC) {
        next_state.set(AppScreen::Cinematic);
    }

    let fwd = (keys.pressed(KeyCode::KeyW) || keys.pressed(KeyCode::ArrowUp)) as i32 as f32
        - (keys.pressed(KeyCode::KeyS) || keys.pressed(KeyCode::ArrowDown)) as i32 as f32
        - stick.y;
    let right = (keys.pressed(KeyCode::KeyD) || keys.pressed(KeyCode::ArrowRight)) as i32 as f32
        - (keys.pressed(KeyCode::KeyA) || keys.pressed(KeyCode::ArrowLeft)) as i32 as f32
        + stick.x;
    let sprint = keys.pressed(KeyCode::ShiftLeft) || keys.pressed(KeyCode::ShiftRight) || stick.x.hypot(stick.y) > 0.91;
    let block = keys.pressed(KeyCode::KeyZ);

    world.step_simulation(dt, fwd, right, sprint, block);
    if world.visit_finished.is_some() {
        next_state.set(AppScreen::End);
    }
}

pub fn handle_ui_buttons(
    mut q: Query<(&Interaction, &UiActionButton), Changed<Interaction>>,
    mut world: ResMut<HollowmereWorld>,
    settings: Res<GameSettings>,
    mut next_state: ResMut<NextState<AppScreen>>,
) {
    for (inter, btn) in &mut q {
        if *inter != Interaction::Pressed {
            continue;
        }
        match btn {
            UiActionButton::StartVillage => {
                world.reset(&settings);
                next_state.set(AppScreen::Play);
            }
            UiActionButton::ToggleSword => world.toggle_sword(),
            UiActionButton::ToggleView => {
                world.player.first_person = !world.player.first_person;
                world.toast(if world.player.first_person { "First-person view" } else { "Third-person view" }, 1.4);
            }
            UiActionButton::Interact => {
                if world.interact().is_some() {
                    next_state.set(AppScreen::Dialogue);
                }
            }
            UiActionButton::Jump => world.jump(),
            UiActionButton::SwordSlash => world.attack(false),
            UiActionButton::SwordHeavy => world.attack(true),
            UiActionButton::SwordBlock => {
                if !world.player.armed {
                    world.toggle_sword();
                }
                world.player.block_toggle = !world.player.block_toggle;
            }
            UiActionButton::Pause => next_state.set(AppScreen::Paused),
            UiActionButton::Resume => next_state.set(AppScreen::Play),
            UiActionButton::NextVista => world.vista_index = (world.vista_index + 1) % 3,
            UiActionButton::PrevVista => world.vista_index = (world.vista_index + 2) % 3,
            UiActionButton::CloseDialogue => {
                world.talking = None;
                next_state.set(AppScreen::Play);
            }
            UiActionButton::AcceptOrAdvanceQuest => {
                if let Some(ni) = world.talking {
                    if ni == 0 {
                        if world.fish_quest == 0 {
                            world.fish_quest = 1;
                            world.toast("Accepted favor: Supper at the Heron (catch 3 silver perch).", 3.0);
                        } else if world.fish_quest == 1 && world.fish >= 3 {
                            world.fish_quest = 2;
                            world.fish = 0;
                            world.add_score(120, "Supper at the Heron complete", true);
                        }
                    } else if ni == 1 {
                        if world.hammer_quest == 0 {
                            world.hammer_quest = 1;
                            world.toast("Accepted favor: A craftsman's companion (find Rowan's hammer).", 3.0);
                        } else if world.hammer_quest == 1 && world.hammer {
                            world.hammer_quest = 2;
                            world.hammer = false;
                            world.add_score(100, "A craftsman's companion complete", true);
                        }
                    }
                    world.talking = None;
                    if world.fish_quest == 2 && world.hammer_quest == 2 {
                        world.bank_record();
                        world.visit_finished = Some(true);
                        next_state.set(AppScreen::End);
                    } else {
                        next_state.set(AppScreen::Play);
                    }
                }
            }
        }
    }
}

#[allow(clippy::too_many_arguments)]
pub fn sync_ui(
    state: Res<State<AppScreen>>,
    world: Res<HollowmereWorld>,
    mut title_q: Query<&mut Visibility, (With<TitleScreenRoot>, Without<HudRoot>, Without<DialogueRoot>, Without<FishUiRoot>)>,
    mut hud_q: Query<&mut Visibility, (With<HudRoot>, Without<TitleScreenRoot>, Without<DialogueRoot>, Without<FishUiRoot>)>,
    mut dlg_q: Query<&mut Visibility, (With<DialogueRoot>, Without<TitleScreenRoot>, Without<HudRoot>, Without<FishUiRoot>)>,
    mut fish_q: Query<&mut Visibility, (With<FishUiRoot>, Without<TitleScreenRoot>, Without<HudRoot>, Without<DialogueRoot>)>,
    mut clock_q: Query<&mut Text, (With<HudClockText>, Without<HudCompassText>, Without<HudObjectiveText>, Without<HudRenownText>, Without<HudInteractText>, Without<HudToastText>, Without<HudSwordLabel>, Without<HudViewLabel>, Without<DialogueSpeakerText>, Without<DialogueBodyText>)>,
    mut compass_q: Query<&mut Text, (With<HudCompassText>, Without<HudClockText>, Without<HudObjectiveText>, Without<HudRenownText>, Without<HudInteractText>, Without<HudToastText>, Without<HudSwordLabel>, Without<HudViewLabel>, Without<DialogueSpeakerText>, Without<DialogueBodyText>)>,
    mut obj_q: Query<&mut Text, (With<HudObjectiveText>, Without<HudClockText>, Without<HudCompassText>, Without<HudRenownText>, Without<HudInteractText>, Without<HudToastText>, Without<HudSwordLabel>, Without<HudViewLabel>, Without<DialogueSpeakerText>, Without<DialogueBodyText>)>,
    mut renown_q: Query<&mut Text, (With<HudRenownText>, Without<HudClockText>, Without<HudCompassText>, Without<HudObjectiveText>, Without<HudInteractText>, Without<HudToastText>, Without<HudSwordLabel>, Without<HudViewLabel>, Without<DialogueSpeakerText>, Without<DialogueBodyText>)>,
    mut interact_q: Query<&mut Text, (With<HudInteractText>, Without<HudClockText>, Without<HudCompassText>, Without<HudObjectiveText>, Without<HudRenownText>, Without<HudToastText>, Without<HudSwordLabel>, Without<HudViewLabel>, Without<DialogueSpeakerText>, Without<DialogueBodyText>)>,
    mut toast_q: Query<&mut Text, (With<HudToastText>, Without<HudClockText>, Without<HudCompassText>, Without<HudObjectiveText>, Without<HudRenownText>, Without<HudInteractText>, Without<HudSwordLabel>, Without<HudViewLabel>, Without<DialogueSpeakerText>, Without<DialogueBodyText>)>,
    mut sword_q: Query<&mut Text, (With<HudSwordLabel>, Without<HudClockText>, Without<HudCompassText>, Without<HudObjectiveText>, Without<HudRenownText>, Without<HudInteractText>, Without<HudToastText>, Without<HudViewLabel>, Without<DialogueSpeakerText>, Without<DialogueBodyText>)>,
    mut view_q: Query<&mut Text, (With<HudViewLabel>, Without<HudClockText>, Without<HudCompassText>, Without<HudObjectiveText>, Without<HudRenownText>, Without<HudInteractText>, Without<HudToastText>, Without<HudSwordLabel>, Without<DialogueSpeakerText>, Without<DialogueBodyText>)>,
    mut spk_q: Query<&mut Text, (With<DialogueSpeakerText>, Without<HudClockText>, Without<HudCompassText>, Without<HudObjectiveText>, Without<HudRenownText>, Without<HudInteractText>, Without<HudToastText>, Without<HudSwordLabel>, Without<HudViewLabel>, Without<DialogueBodyText>)>,
    mut body_q: Query<&mut Text, (With<DialogueBodyText>, Without<HudClockText>, Without<HudCompassText>, Without<HudObjectiveText>, Without<HudRenownText>, Without<HudInteractText>, Without<HudToastText>, Without<HudSwordLabel>, Without<HudViewLabel>, Without<DialogueSpeakerText>)>,
    mut pin_q: Query<&mut Node, With<FishPinNode>>,
) {
    let cur = *state.get();
    if let Ok(mut v) = title_q.get_single_mut() {
        *v = if matches!(cur, AppScreen::Menu | AppScreen::Loading) { Visibility::Visible } else { Visibility::Hidden };
    }
    if let Ok(mut v) = hud_q.get_single_mut() {
        *v = if cur == AppScreen::Play { Visibility::Visible } else { Visibility::Hidden };
    }
    if let Ok(mut v) = dlg_q.get_single_mut() {
        *v = if cur == AppScreen::Dialogue { Visibility::Visible } else { Visibility::Hidden };
    }
    if let Ok(mut v) = fish_q.get_single_mut() {
        *v = if cur == AppScreen::Play && world.fishing.is_some() { Visibility::Visible } else { Visibility::Hidden };
    }
    if let Ok(mut t) = clock_q.get_single_mut() {
        t.0 = fmt_time(world.hour);
    }
    if let Ok(mut t) = compass_q.get_single_mut() {
        const DIRS: [&str; 8] = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
        let i = ((-world.player.yaw / FRAC_PI_4).round() as i32).rem_euclid(8) as usize;
        t.0 = format!("{}   [ {} ]   {}", DIRS[(i + 7) % 8], DIRS[i], DIRS[(i + 1) % 8]);
    }
    if let Ok(mut t) = obj_q.get_single_mut() {
        t.0 = world.objective();
    }
    if let Ok(mut t) = renown_q.get_single_mut() {
        t.0 = format!("{} RENOWN", world.score);
    }
    if let Ok(mut t) = interact_q.get_single_mut() {
        t.0 = world.target().map(|a| format!("[E] {}", a.prompt(&world))).unwrap_or_default();
    }
    if let Ok(mut t) = toast_q.get_single_mut() {
        t.0 = world.toast_text.as_ref().map(|(s, _)| s.clone()).unwrap_or_default();
    }
    if let Ok(mut t) = sword_q.get_single_mut() {
        t.0 = if world.player.armed { "ARMED".into() } else { "SWORD".into() };
    }
    if let Ok(mut t) = view_q.get_single_mut() {
        t.0 = if world.player.first_person { "1ST".into() } else { "3RD".into() };
    }
    if let Some(ref f) = world.fishing {
        if let Ok(mut node) = pin_q.get_single_mut() {
            node.left = Val::Percent(f.pin * 100.0);
        }
    }
    if let Some(ni) = world.talking {
        let p = crate::data::PEOPLE[ni];
        if let Ok(mut t) = spk_q.get_single_mut() {
            t.0 = format!("{} — {}", p.name, p.role);
        }
        if let Ok(mut t) = body_q.get_single_mut() {
            t.0 = p.hello.into();
        }
    }
}
