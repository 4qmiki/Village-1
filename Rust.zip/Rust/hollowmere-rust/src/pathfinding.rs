use std::collections::HashMap;

use crate::collision::CollisionWorld;
use crate::data::BuildingSpec;

/// Exact 8-connected A* navigation grid matching JS `findPath(sx, sz, ex, ez)`.
pub fn find_path(
    buildings: &[BuildingSpec],
    col: &CollisionWorld,
    sx: f32,
    sz: f32,
    ex: f32,
    ez: f32,
) -> Vec<[f32; 2]> {
    let cell = 2.1f32;
    let si = (sx / cell).round() as i32;
    let sj = (sz / cell).round() as i32;
    let ei = (ex / cell).round() as i32;
    let ej = (ez / cell).round() as i32;

    #[derive(Clone)]
    struct Node {
        i: i32,
        j: i32,
        g: f32,
        f: f32,
        prev: Option<usize>,
    }

    let mut nodes: Vec<Node> = vec![Node {
        i: si,
        j: sj,
        g: 0.0,
        f: 0.0,
        prev: None,
    }];
    let mut open: Vec<usize> = vec![0];
    let mut seen: HashMap<(i32, i32), f32> = HashMap::new();
    seen.insert((si, sj), 0.0);

    let mut best_idx = 0usize;
    let mut best_d = 1e6f32;

    for _ in 0..1100 {
        if open.is_empty() {
            break;
        }
        let mut mi = 0usize;
        for k in 1..open.len() {
            if nodes[open[k]].f < nodes[open[mi]].f {
                mi = k;
            }
        }
        let cur_idx = open.swap_remove(mi);
        let cur_i = nodes[cur_idx].i;
        let cur_j = nodes[cur_idx].j;
        let cur_g = nodes[cur_idx].g;

        let d = ((cur_i - ei) as f32).hypot((cur_j - ej) as f32);
        if d < best_d {
            best_idx = cur_idx;
            best_d = d;
        }
        if d < 1.01 {
            break;
        }

        for di in -1..=1 {
            for dj in -1..=1 {
                if di == 0 && dj == 0 {
                    continue;
                }
                let ni = cur_i + di;
                let nj = cur_j + dj;
                if ni.abs() > 34 || nj.abs() > 32 {
                    continue;
                }
                if col.blocked(buildings, ni as f32 * cell, nj as f32 * cell, 0.35, None, &[]) {
                    continue;
                }
                if di != 0
                    && dj != 0
                    && (col.blocked(
                        buildings,
                        ni as f32 * cell,
                        cur_j as f32 * cell,
                        0.32,
                        None,
                        &[],
                    ) || col.blocked(
                        buildings,
                        cur_i as f32 * cell,
                        nj as f32 * cell,
                        0.32,
                        None,
                        &[],
                    ))
                {
                    continue;
                }
                let g = cur_g + (di as f32).hypot(dj as f32);
                if let Some(&prev_g) = seen.get(&(ni, nj)) {
                    if prev_g <= g {
                        continue;
                    }
                }
                seen.insert((ni, nj), g);
                let new_idx = nodes.len();
                nodes.push(Node {
                    i: ni,
                    j: nj,
                    g,
                    f: g + ((ni - ei) as f32).hypot((nj - ej) as f32),
                    prev: Some(cur_idx),
                });
                open.push(new_idx);
            }
        }
    }

    let mut out = Vec::new();
    let mut cursor = best_idx;
    while let Some(prev) = nodes[cursor].prev {
        out.push([nodes[cursor].i as f32 * cell, nodes[cursor].j as f32 * cell]);
        cursor = prev;
    }
    out.reverse();
    if !col.blocked(buildings, ex, ez, 0.32, None, &[]) {
        out.push([ex, ez]);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::data::build_buildings;

    #[test]
    fn finds_path_along_main_road() {
        let buildings = build_buildings();
        let col = CollisionWorld::new(&buildings);
        let path = find_path(&buildings, &col, 5.0, 20.0, 5.0, -10.0);
        assert!(!path.is_empty());
        let last = path.last().unwrap();
        assert!((last[0] - 5.0).hypot(last[1] + 10.0) < 3.0);
    }
}
