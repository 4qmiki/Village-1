use bevy::prelude::*;
use bevy::render::render_asset::RenderAssetUsages;
use bevy::render::render_resource::{Extent3d, TextureDimension, TextureFormat};

use crate::math::{clamp, fbm, mix, noise, smooth, SeededRng};

#[derive(Resource)]
pub struct HollowmereMaterials {
    pub wood: Handle<StandardMaterial>,
    pub lightwood: Handle<StandardMaterial>,
    pub darkwood: Handle<StandardMaterial>,
    pub bark_oak: Handle<StandardMaterial>,
    pub bark_birch: Handle<StandardMaterial>,
    pub stone: Handle<StandardMaterial>,
    pub slate: Handle<StandardMaterial>,
    pub thatch: Handle<StandardMaterial>,
    pub plaster: Handle<StandardMaterial>,
    pub grass: Handle<StandardMaterial>,
    pub dirt: Handle<StandardMaterial>,
    pub iron: Handle<StandardMaterial>,
    pub black: Handle<StandardMaterial>,
    pub rug: Handle<StandardMaterial>,
    pub cloth_blue: Handle<StandardMaterial>,
    pub cloth_cream: Handle<StandardMaterial>,
    pub bread: Handle<StandardMaterial>,
    pub ceramic: Handle<StandardMaterial>,
    pub brass: Handle<StandardMaterial>,
    pub steel: Handle<StandardMaterial>,
    pub cheese: Handle<StandardMaterial>,
    pub roast: Handle<StandardMaterial>,
    pub window: Handle<StandardMaterial>,
    pub fire: Handle<StandardMaterial>,
    pub gold: Handle<StandardMaterial>,
    pub pine_foliage: Handle<StandardMaterial>,
    pub oak_foliage: Handle<StandardMaterial>,
    pub birch_foliage: Handle<StandardMaterial>,
    pub mountain: Handle<StandardMaterial>,
}

fn make_rgba_image(size: u32, data: Vec<u8>, srgb: bool) -> Image {
    Image::new(
        Extent3d {
            width: size,
            height: size,
            depth_or_array_layers: 1,
        },
        TextureDimension::D2,
        data,
        if srgb {
            TextureFormat::Rgba8UnormSrgb
        } else {
            TextureFormat::Rgba8Unorm
        },
        RenderAssetUsages::RENDER_WORLD,
    )
}

fn generate_surface(
    images: &mut Assets<Image>,
    materials: &mut Assets<StandardMaterial>,
    kind: &str,
    base: [u8; 3],
    roughness: f32,
    metallic: f32,
) -> Handle<StandardMaterial> {
    let s = 256u32;
    let mut albedo = vec![0u8; (s * s * 4) as usize];
    let mut rng = SeededRng::new(359 + (kind.len() as i32) * 31);

    for y in 0..s {
        for x in 0..s {
            let u = x as f32 / s as f32;
            let v = y as f32 / s as f32;
            let idx = ((y * s + x) * 4) as usize;
            let mut c = [base[0] as f32, base[1] as f32, base[2] as f32];
            let gr = (rng.next_f32() - 0.5) * 14.0;

            match kind {
                "stone" | "shingle" => {
                    let rows = if kind == "stone" { 8.0 } else { 14.0 };
                    let cols = if kind == "stone" { 5.0 } else { 9.0 };
                    let row = (v * rows).floor();
                    let shift = if (row as i32) % 2 != 0 { 0.5 } else { 0.0 };
                    let fy = (v * rows).fract();
                    let fx = (u * cols + shift).fract();
                    let mortar = fy < 0.07 || fx < 0.05;
                    let tile_n = noise(row * 1.7, (u * cols + shift).floor() * 2.3);
                    let delta = if mortar { -32.0 } else { (tile_n - 0.5) * 30.0 };
                    for ch in 0..3 {
                        c[ch] = clamp(c[ch] + delta + gr * 0.6, 0.0, 255.0);
                    }
                }
                "barkOak" => {
                    let warp = fbm(u * 6.0 + 2.0, v * 3.5 + 5.0) * 1.4;
                    let r1 = ((u * 11.0 + warp) * std::f32::consts::PI).sin().abs();
                    let r2 = ((u * 23.0 - warp * 1.3) * std::f32::consts::PI).sin().abs();
                    let plate = r1.powf(0.52) * 0.68 + r2.powf(0.65) * 0.32;
                    let fissure = smooth(0.18, 0.45, plate);
                    let moss = smooth(0.56, 0.78, fbm(u * 7.5 + 14.0, v * 7.5 + 9.0)) * (1.0 - fissure * 0.65);
                    let dark = [34.0, 27.0, 20.0];
                    let moss_c = [78.0, 96.0, 54.0];
                    for ch in 0..3 {
                        let b = mix(dark[ch], c[ch], fissure);
                        c[ch] = clamp(mix(b, moss_c[ch], moss * 0.55) + gr, 0.0, 255.0);
                    }
                }
                "barkBirch" => {
                    let n = fbm(u * 8.0 + 4.0, v * 14.0 + 2.0);
                    let lenticel = smooth(0.79, 0.88, noise(u * 5.0, v * 58.0));
                    for ch in 0..3 {
                        let base_v = mix(186.0, 228.0, n);
                        c[ch] = clamp(mix(base_v, 44.0, lenticel * 0.75) + gr * 0.6, 0.0, 255.0);
                    }
                }
                "wood" | "planks" | "thatch" => {
                    let grain = fbm(u * 18.0, v * 3.0) - 0.5;
                    let plank_seam = if kind == "planks" && (u * 6.0).fract() < 0.04 { -34.0 } else { 0.0 };
                    for ch in 0..3 {
                        c[ch] = clamp(c[ch] + grain * 44.0 + plank_seam + gr, 0.0, 255.0);
                    }
                }
                "grass" => {
                    let n1 = fbm(u * 9.0 + 2.0, v * 9.0 + 4.0);
                    let n2 = fbm(u * 24.0 + 11.0, v * 24.0 + 7.0);
                    let lo = [118.0, 124.0, 84.0];
                    let hi = [178.0, 184.0, 132.0];
                    for ch in 0..3 {
                        c[ch] = clamp(mix(lo[ch], hi[ch], clamp(n1 * 0.65 + n2 * 0.35, 0.0, 1.0)) + gr, 0.0, 255.0);
                    }
                }
                "steel" => {
                    let streak = noise(x as f32 * 0.03, y as f32 * 0.65) * 24.0 + fbm(u * 12.0, v * 12.0) * 18.0;
                    let val = clamp(192.0 + streak - 18.0, 125.0, 248.0);
                    c = [val * 0.96, val * 0.99, clamp(val * 1.03, 0.0, 255.0)];
                }
                _ => {
                    let n = (fbm(u * 9.0, v * 9.0) - 0.5) * 42.0;
                    for ch in 0..3 {
                        c[ch] = clamp(c[ch] + n + gr, 0.0, 255.0);
                    }
                }
            }
            albedo[idx] = c[0] as u8;
            albedo[idx + 1] = c[1] as u8;
            albedo[idx + 2] = c[2] as u8;
            albedo[idx + 3] = 255;
        }
    }

    // Sobel normal map derived from albedo luminance (matches JS `makeNormalAndORM`)
    let mut normal = vec![0u8; (s * s * 4) as usize];
    let lum = |xx: i32, yy: i32| -> f32 {
        let wx = xx.rem_euclid(s as i32) as usize;
        let wy = yy.rem_euclid(s as i32) as usize;
        let p = (wy * s as usize + wx) * 4;
        albedo[p] as f32 * 0.299 + albedo[p + 1] as f32 * 0.587 + albedo[p + 2] as f32 * 0.114
    };
    for y in 0..s as i32 {
        for x in 0..s as i32 {
            let tl = lum(x - 1, y - 1);
            let tc = lum(x, y - 1);
            let tr = lum(x + 1, y - 1);
            let ml = lum(x - 1, y);
            let mr = lum(x + 1, y);
            let bl = lum(x - 1, y + 1);
            let bc = lum(x, y + 1);
            let br = lum(x + 1, y + 1);
            let dx = (tr + 2.0 * mr + br - tl - 2.0 * ml - bl) * 0.45;
            let dy = (bl + 2.0 * bc + br - tl - 2.0 * tc - tr) * 0.45;
            let len = (dx * dx + dy * dy + 255.0 * 255.0).sqrt();
            let p = ((y as u32 * s + x as u32) * 4) as usize;
            normal[p] = clamp(128.0 - dx / len * 127.0, 0.0, 255.0) as u8;
            normal[p + 1] = clamp(128.0 + dy / len * 127.0, 0.0, 255.0) as u8;
            normal[p + 2] = clamp(128.0 + 255.0 / len * 127.0, 128.0, 255.0) as u8;
            normal[p + 3] = 255;
        }
    }

    let base_tex = images.add(make_rgba_image(s, albedo, true));
    let norm_tex = images.add(make_rgba_image(s, normal, false));
    materials.add(StandardMaterial {
        base_color_texture: Some(base_tex),
        normal_map_texture: Some(norm_tex),
        perceptual_roughness: roughness,
        metallic,
        ..default()
    })
}

pub fn create_materials(
    images: &mut Assets<Image>,
    materials: &mut Assets<StandardMaterial>,
) -> HollowmereMaterials {
    let solid = |mats: &mut Assets<StandardMaterial>, r: u8, g: u8, b: u8, rough: f32, metal: f32| {
        mats.add(StandardMaterial {
            base_color: Color::srgb_u8(r, g, b),
            perceptual_roughness: rough,
            metallic: metal,
            ..default()
        })
    };

    HollowmereMaterials {
        wood: generate_surface(images, materials, "wood", [105, 82, 53], 0.92, 0.0),
        lightwood: generate_surface(images, materials, "planks", [151, 127, 86], 0.88, 0.0),
        darkwood: generate_surface(images, materials, "wood", [83, 72, 52], 0.94, 0.0),
        bark_oak: generate_surface(images, materials, "barkOak", [86, 71, 52], 0.95, 0.0),
        bark_birch: generate_surface(images, materials, "barkBirch", [214, 210, 196], 0.9, 0.0),
        stone: generate_surface(images, materials, "stone", [148, 150, 125], 0.94, 0.0),
        slate: generate_surface(images, materials, "shingle", [105, 113, 100], 0.87, 0.0),
        thatch: generate_surface(images, materials, "thatch", [161, 137, 82], 0.96, 0.0),
        plaster: generate_surface(images, materials, "plaster", [201, 193, 159], 0.93, 0.0),
        grass: generate_surface(images, materials, "grass", [182, 183, 143], 0.88, 0.0),
        dirt: generate_surface(images, materials, "dirt", [168, 151, 115], 0.94, 0.0),
        iron: solid(materials, 73, 77, 67, 0.56, 0.65),
        black: solid(materials, 56, 63, 53, 0.92, 0.0),
        rug: solid(materials, 125, 62, 52, 0.94, 0.0),
        cloth_blue: solid(materials, 70, 98, 120, 0.88, 0.0),
        cloth_cream: solid(materials, 223, 213, 182, 0.9, 0.0),
        bread: generate_surface(images, materials, "plaster", [198, 142, 74], 0.88, 0.0),
        ceramic: solid(materials, 201, 186, 160, 0.42, 0.0),
        brass: solid(materials, 216, 180, 92, 0.28, 0.78),
        steel: generate_surface(images, materials, "steel", [196, 204, 208], 0.24, 0.88),
        cheese: generate_surface(images, materials, "plaster", [220, 184, 88], 0.8, 0.0),
        roast: generate_surface(images, materials, "plaster", [142, 74, 44], 0.75, 0.0),
        window: materials.add(StandardMaterial {
            base_color: Color::srgb_u8(187, 163, 112),
            emissive: LinearRgba::rgb(1.4, 0.95, 0.42),
            perceptual_roughness: 0.36,
            metallic: 0.21,
            ..default()
        }),
        fire: materials.add(StandardMaterial {
            base_color: Color::srgb_u8(255, 173, 67),
            emissive: LinearRgba::rgb(4.5, 2.2, 0.45),
            perceptual_roughness: 1.0,
            ..default()
        }),
        gold: materials.add(StandardMaterial {
            base_color: Color::srgb_u8(222, 189, 96),
            emissive: LinearRgba::rgb(0.65, 0.5, 0.16),
            perceptual_roughness: 0.55,
            ..default()
        }),
        pine_foliage: solid(materials, 54, 84, 58, 0.82, 0.0),
        oak_foliage: solid(materials, 96, 126, 66, 0.76, 0.0),
        birch_foliage: solid(materials, 134, 158, 82, 0.74, 0.0),
        mountain: generate_surface(images, materials, "stone", [128, 134, 128], 0.92, 0.02),
    }
}
