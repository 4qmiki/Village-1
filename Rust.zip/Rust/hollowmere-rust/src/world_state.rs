use std::collections::HashSet;
use std::f32::consts::PI;

use bevy::prelude::*;
use serde::{Deserialize, Serialize};

use crate::collision::CollisionWorld;
use crate::data::{
    build_buildings, BuildingKind, BuildingSpec, EatKind, NpcActivity, QualityTier, SurfaceKind,
    WeatherKind, HORSES, MEREBELL_SPOTS, PEOPLE,
};
use crate::math::{clamp, mix, SeededRng};
use crate::pathfinding::find_path;
use crate::terrain::Terrain;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VisitRecord {
    pub score: u32,
    pub quests: u8,
    pub met: usize,
    pub seconds: u32,
}

#[derive(Debug, Clone, Resource, Serialize, Deserialize)]
pub struct GameSettings {
    pub quality: QualityTier,
    pub fps: bool,
    pub hour: f32,
    pub weather: WeatherKind,
    pub volume: f32,
    pub sound_enabled: bool,
}

impl Default for GameSettings {
    fn default() -> Self {
        Self {
            quality: QualityTier::High,
            fps: false,
            hour: 17.5,
            weather: WeatherKind::Clear,
            volume: 0.48,
            sound_enabled: true,
        }
    }
}

#[derive(Debug, Clone)]
pub struct HorseState {
    pub id: usize,
    pub name: &'static str,
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub angle: f32,
    pub speed: f32,
    pub sprint: bool,
    pub jump_h: f32,
    pub phase: f32,
}

#[derive(Debug, Clone)]
pub struct PlayerState {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub angle: f32,
    pub yaw: f32,
    pub pitch: f32,
    pub speed: f32,
    pub vx: f32,
    pub vz: f32,
    pub jump_h: f32,
    pub vy: f32,
    pub phase: f32,
    pub steps: f32,
    pub first_person: bool,
    pub lantern: bool,
    pub sprint: bool,
    pub current_room: Option<usize>,
    pub eating: f32,
    pub eat_kind: EatKind,
    pub reel_anim: f32,
    pub catch_anim: f32,
    pub armed: bool,
    pub draw_anim: f32,
    pub attack_anim: f32,
    pub combo: u8,
    pub combo_timer: f32,
    pub blocking: bool,
    pub block_toggle: bool,
    pub land_anim: f32,
    pub hit_checked: bool,
    pub horse_idx: Option<usize>,
    pub yaw_vel: f32,
    pub last_yaw: f32,
    pub interact_anim: f32,
    pub heavy_attack: bool,
    pub on_stairs: bool,
}

impl PlayerState {
    pub fn new(buildings: &[BuildingSpec]) -> Self {
        let x = 5.4;
        let z = 23.0;
        let y = Terrain::walk(buildings, x, z, None);
        Self {
            x,
            y,
            z,
            angle: PI,
            yaw: 0.18,
            pitch: 0.19,
            speed: 0.0,
            vx: 0.0,
            vz: 0.0,
            jump_h: 0.0,
            vy: 0.0,
            phase: 0.0,
            steps: 0.0,
            first_person: false,
            lantern: false,
            sprint: false,
            current_room: None,
            eating: 0.0,
            eat_kind: EatKind::Bread,
            reel_anim: 0.0,
            catch_anim: 0.0,
            armed: false,
            draw_anim: 0.0,
            attack_anim: 0.0,
            combo: 0,
            combo_timer: 0.0,
            blocking: false,
            block_toggle: false,
            land_anim: 0.0,
            hit_checked: false,
            horse_idx: None,
            yaw_vel: 0.0,
            last_yaw: 0.18,
            interact_anim: 0.0,
            heavy_attack: false,
            on_stairs: false,
        }
    }
}

#[derive(Debug, Clone)]
pub struct NpcState {
    pub id: usize,
    pub name: &'static str,
    pub role: &'static str,
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub start: [f32; 2],
    pub home: usize,
    pub angle: f32,
    pub phase: f32,
    pub path: Vec<[f32; 2]>,
    pub wait: f32,
    pub speed: f32,
    pub activity: NpcActivity,
    pub head: f32,
    pub rng: SeededRng,
    pub hp: i32,
    pub max_hp: i32,
    pub hurt_timer: f32,
    pub flee_timer: f32,
    pub down_timer: f32,
    pub knock_vx: f32,
    pub knock_vz: f32,
    pub hit_dir: f32,
}

#[derive(Debug, Clone)]
pub struct FishingState {
    pub time: f32,
    pub pin: f32,
    pub cast_t: f32,
    pub bob_x: f32,
    pub bob_z: f32,
    pub splashed: bool,
}

#[derive(Debug, Clone)]
pub struct FlowerSpot {
    pub x: f32,
    pub z: f32,
    pub taken: bool,
}

#[derive(Debug, Clone)]
pub struct Particle {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub vx: f32,
    pub vy: f32,
    pub vz: f32,
    pub life: f32,
    pub color: Color,
}

#[derive(Debug, Clone)]
pub enum InteractionTarget {
    Reel,
    Dismount(usize),
    Mount(usize),
    Door(usize),
    Hammer,
    Fish,
    Npc(usize),
    Well,
    Bed,
    Interior {
        id: &'static str,
        text: &'static str,
        msg: &'static str,
        building_name: &'static str,
    },
}

impl InteractionTarget {
    pub fn prompt(&self, world: &HollowmereWorld) -> String {
        match self {
            Self::Reel => "Reel in your line".into(),
            Self::Dismount(i) => format!("Dismount {}", world.horses[*i].name),
            Self::Mount(i) => format!("Mount {}", world.horses[*i].name),
            Self::Door(i) => {
                let dr = &world.collision.doors[*i];
                if dr.target > 0.0 {
                    format!("Close door — {}", dr.name)
                } else {
                    format!("Open door — {}", dr.name)
                }
            }
            Self::Hammer => "Pick up Rowan's hammer".into(),
            Self::Fish => "Cast a fishing line".into(),
            Self::Npc(i) => format!("Talk to {}", world.npcs[*i].name),
            Self::Well => "Make a wish at the well".into(),
            Self::Bed => "Rest in your bed until morning".into(),
            Self::Interior { text, .. } => (*text).into(),
        }
    }
}

#[derive(Debug, Clone)]
pub enum SoundEvent {
    Step(SurfaceKind, f32),
    Tone { freq: f32, dur: f32, power: f32, end_freq: f32 },
    Reward { big: bool },
}

#[derive(Resource)]
pub struct HollowmereWorld {
    pub buildings: Vec<BuildingSpec>,
    pub collision: CollisionWorld,
    pub player: PlayerState,
    pub npcs: Vec<NpcState>,
    pub horses: Vec<HorseState>,
    pub hour: f32,
    pub rate: f32,
    pub weather: WeatherKind,
    pub elapsed: f32,
    pub score: u32,
    pub met: HashSet<usize>,
    pub fish: u8,
    pub fish_quest: u8,
    pub hammer_quest: u8,
    pub hammer: bool,
    pub talking: Option<usize>,
    pub fishing: Option<FishingState>,
    pub discover: HashSet<String>,
    pub particles: Vec<Particle>,
    pub shake: f32,
    pub last_ripple: [f32; 3],
    pub flowers: Vec<FlowerSpot>,
    pub records: Vec<VisitRecord>,
    pub toast_text: Option<(String, f32)>,
    pub sound_queue: Vec<SoundEvent>,
    pub visit_finished: Option<bool>,
    pub vista_index: usize,
    pub photo_distance: f32,
    pub fx_rng: SeededRng,
}

impl HollowmereWorld {
    pub fn new() -> Self {
        let buildings = build_buildings();
        let collision = CollisionWorld::new(&buildings);
        let mut w = Self {
            player: PlayerState::new(&buildings),
            npcs: Self::spawn_npcs(&buildings),
            horses: Self::spawn_horses(&buildings),
            buildings,
            collision,
            hour: 17.5,
            rate: 1.0,
            weather: WeatherKind::Clear,
            elapsed: 0.0,
            score: 0,
            met: HashSet::new(),
            fish: 0,
            fish_quest: 0,
            hammer_quest: 0,
            hammer: false,
            talking: None,
            fishing: None,
            discover: HashSet::new(),
            particles: Vec::new(),
            shake: 0.0,
            last_ripple: [-14.0, 0.0, -100.0],
            flowers: MEREBELL_SPOTS
                .iter()
                .map(|[x, z]| FlowerSpot { x: *x, z: *z, taken: false })
                .collect(),
            records: Vec::new(),
            toast_text: None,
            sound_queue: Vec::new(),
            visit_finished: None,
            vista_index: 0,
            photo_distance: 6.8,
            fx_rng: SeededRng::new(2026),
        };
        w.toast("Welcome to Hollowmere", 2.8);
        w
    }

    pub fn reset(&mut self, settings: &GameSettings) {
        self.player = PlayerState::new(&self.buildings);
        self.npcs = Self::spawn_npcs(&self.buildings);
        self.horses = Self::spawn_horses(&self.buildings);
        self.hour = settings.hour;
        self.rate = 1.0;
        self.weather = settings.weather;
        self.elapsed = 0.0;
        self.score = 0;
        self.met.clear();
        self.fish = 0;
        self.fish_quest = 0;
        self.hammer_quest = 0;
        self.hammer = false;
        self.talking = None;
        self.fishing = None;
        self.discover.clear();
        self.particles.clear();
        self.shake = 0.0;
        self.last_ripple = [-14.0, 0.0, -100.0];
        self.visit_finished = None;
        for f in &mut self.flowers {
            f.taken = false;
        }
    }

    fn spawn_npcs(buildings: &[BuildingSpec]) -> Vec<NpcState> {
        PEOPLE
            .iter()
            .map(|p| NpcState {
                id: p.id,
                name: p.name,
                role: p.role,
                x: p.x,
                y: Terrain::walk(buildings, p.x, p.z, None),
                z: p.z,
                start: [p.x, p.z],
                home: p.home,
                angle: 2.5 - p.id as f32 * 0.74,
                phase: p.id as f32 * 2.3,
                path: Vec::new(),
                wait: 18.0 + p.id as f32 * 2.0,
                speed: 0.0,
                activity: NpcActivity::Work,
                head: 0.0,
                rng: SeededRng::new(330 + p.id as i32),
                hp: 100,
                max_hp: 100,
                hurt_timer: 0.0,
                flee_timer: 0.0,
                down_timer: 0.0,
                knock_vx: 0.0,
                knock_vz: 0.0,
                hit_dir: 0.0,
            })
            .collect()
    }

    fn spawn_horses(buildings: &[BuildingSpec]) -> Vec<HorseState> {
        HORSES
            .iter()
            .enumerate()
            .map(|(id, h)| HorseState {
                id,
                name: h.name,
                x: h.x,
                y: Terrain::walk(buildings, h.x, h.z, None),
                z: h.z,
                angle: h.angle,
                speed: 0.0,
                sprint: false,
                jump_h: 0.0,
                phase: 0.0,
            })
            .collect()
    }

    pub fn toast(&mut self, msg: impl Into<String>, secs: f32) {
        self.toast_text = Some((msg.into(), secs));
    }

    pub fn burst(&mut self, x: f32, y: f32, z: f32, n: usize, color: Color) {
        for _ in 0..n {
            self.particles.push(Particle {
                x,
                y,
                z,
                vx: (self.fx_rng.next_f32() - 0.5) * 2.4,
                vy: 0.5 + self.fx_rng.next_f32() * 2.4,
                vz: (self.fx_rng.next_f32() - 0.5) * 2.4,
                life: 0.55 + self.fx_rng.next_f32() * 0.6,
                color,
            });
        }
        if self.particles.len() > 150 {
            let drain = self.particles.len() - 150;
            self.particles.drain(0..drain);
        }
    }

    pub fn ripple(&mut self, x: f32, z: f32) {
        self.last_ripple = [x, z, self.elapsed];
    }

    pub fn add_score(&mut self, points: u32, label: &str, big: bool) {
        self.score += points;
        self.shake = if big { 0.08 } else { 0.018 };
        self.burst(
            self.player.x,
            self.player.y + 0.8,
            self.player.z,
            if big { 28 } else { 13 },
            Color::srgb_u8(223, 193, 125),
        );
        self.sound_queue.push(SoundEvent::Reward { big });
        self.toast(format!("{label}  +{points} renown"), 2.6);
    }

    pub fn objective(&self) -> String {
        if self.fish_quest == 1 {
            if self.fish >= 3 {
                "Bring three fish to Elin".into()
            } else {
                format!("Catch fish at the lake dock ({}/3)", self.fish)
            }
        } else if self.hammer_quest == 1 {
            if self.hammer {
                "Return the hammer to Rowan".into()
            } else {
                "Find the lost hammer by the fisherman's hut".into()
            }
        } else if self.fish_quest == 0 {
            "Meet Elin, the innkeeper".into()
        } else if self.hammer_quest == 0 {
            "Speak with Rowan at the forge".into()
        } else {
            "A friend to the village".into()
        }
    }

    pub fn nearest_npc(&self, range: f32) -> Option<usize> {
        let mut best = None;
        let mut min_d = range;
        for (i, n) in self.npcs.iter().enumerate() {
            if n.activity == NpcActivity::Sleep && n.path.is_empty() {
                continue;
            }
            let d = (self.player.x - n.x).hypot(self.player.z - n.z);
            if d < min_d {
                min_d = d;
                best = Some(i);
            }
        }
        best
    }

    pub fn target(&self) -> Option<InteractionTarget> {
        let p = &self.player;
        if self.fishing.is_some() {
            return Some(InteractionTarget::Reel);
        }
        if let Some(hi) = p.horse_idx {
            return Some(InteractionTarget::Dismount(hi));
        }
        for (i, h) in self.horses.iter().enumerate() {
            if (p.x - h.x).hypot(p.z - h.z) < 2.55 {
                return Some(InteractionTarget::Mount(i));
            }
        }
        for (i, dr) in self.collision.doors.iter().enumerate() {
            if (p.x - dr.x).hypot(p.z - dr.z) < 2.35 {
                return Some(InteractionTarget::Door(i));
            }
        }
        if self.hammer_quest == 1 && !self.hammer && (p.x + 5.7).hypot(p.z - 3.65) < 2.8 {
            return Some(InteractionTarget::Hammer);
        }
        if Terrain::dock(p.x, p.z) && p.x < -11.4 {
            return Some(InteractionTarget::Fish);
        }
        if let Some(ni) = self.nearest_npc(3.2) {
            return Some(InteractionTarget::Npc(ni));
        }
        if (p.x - 9.5).hypot(p.z + 0.6) < 3.0 {
            return Some(InteractionTarget::Well);
        }
        if let Some(room) = Terrain::inside(&self.buildings, p.x, p.z, 0.0) {
            match room.kind {
                BuildingKind::Inn if (p.x - (room.x - 2.4)).hypot(p.z - (room.z - 1.2)) < 2.5 => {
                    return Some(InteractionTarget::Interior {
                        id: "inn-bar",
                        text: "Inspect the tavern fare & ale",
                        msg: "Fresh perch stew, warm rye loaves, and spiced honey mead simmer behind the oak bar.",
                        building_name: room.name,
                    });
                }
                BuildingKind::Bakery if (p.x - room.x).hypot(p.z - (room.z - 0.5)) < 2.4 => {
                    return Some(InteractionTarget::Interior {
                        id: "bakery-goods",
                        text: "Smell the fresh hearth bread",
                        msg: "Warm sourdough, honeyed oat cakes, and wheels of valley cheese line Mara's counter.",
                        building_name: room.name,
                    });
                }
                BuildingKind::Herbs if (p.x - room.x).hypot(p.z - (room.z - 0.5)) < 2.4 => {
                    return Some(InteractionTarget::Interior {
                        id: "herbs-shelf",
                        text: "Examine the apothecary bottles",
                        msg: "Dried merebells, willow bark tinctures, and lavender salves glow softly on the shelves.",
                        building_name: room.name,
                    });
                }
                BuildingKind::Forge if (p.x - room.x).hypot(p.z - (room.z - 0.5)) < 2.4 => {
                    return Some(InteractionTarget::Interior {
                        id: "forge-rack",
                        text: "Inspect Rowan's forged blades",
                        msg: "Well-balanced axes, tempered iron hinges, and gleaming lantern brackets line the rack.",
                        building_name: room.name,
                    });
                }
                BuildingKind::Weaver if (p.x - room.x).hypot(p.z - (room.z - 0.4)) < 2.4 => {
                    return Some(InteractionTarget::Interior {
                        id: "weaver-loom",
                        text: "Admire the woad-dyed tapestry",
                        msg: "Deep lake-blue wool threads are woven into a pattern of mountains and ripples.",
                        building_name: room.name,
                    });
                }
                BuildingKind::Chapel if (p.x - room.x).hypot(p.z - (room.z - 2.5)) < 2.8 => {
                    return Some(InteractionTarget::Interior {
                        id: "chapel-altar",
                        text: "Read the illuminated chronicle",
                        msg: "The parchment tells of Hollowmere's founding beside the quiet waters of the Mere.",
                        building_name: room.name,
                    });
                }
                BuildingKind::Home if p.y > room.floor_y + 2.0 && (p.x - (room.x + 1.9)).hypot(p.z - (room.z - 1.2)) < 2.4 => {
                    return Some(InteractionTarget::Bed);
                }
                BuildingKind::Home if p.y < room.floor_y + 1.5 && (p.x - (room.x + 1.5)).hypot(p.z - (room.z + 0.5)) < 2.4 => {
                    return Some(InteractionTarget::Interior {
                        id: "home-table",
                        text: "Eat a home-cooked meal",
                        msg: "A hearty roast and warm bread await on your oak dining table.",
                        building_name: room.name,
                    });
                }
                _ => {}
            }
        }
        None
    }

    pub fn mount_or_dismount(&mut self, horse_idx: Option<usize>) {
        if let Some(cur) = self.player.horse_idx {
            let h = self.horses[cur].clone();
            let mut dx = h.x + h.angle.cos() * 1.35;
            let mut dz = h.z - h.angle.sin() * 1.35;
            if self.collision.blocked(&self.buildings, dx, dz, 0.34, Some(self.player.y), &[]) {
                dx = h.x - h.angle.cos() * 1.35;
                dz = h.z + h.angle.sin() * 1.35;
            }
            if self.collision.blocked(&self.buildings, dx, dz, 0.34, Some(self.player.y), &[]) {
                dx = h.x;
                dz = h.z;
            }
            self.player.horse_idx = None;
            self.player.x = dx;
            self.player.z = dz;
            self.player.y = Terrain::walk(&self.buildings, dx, dz, Some(self.player.y));
            self.sound_queue.push(SoundEvent::Step(SurfaceKind::Grass, 1.1));
            self.toast(format!("Dismounted {}.", h.name), 1.8);
            return;
        }
        if let Some(hi) = horse_idx {
            let h = &self.horses[hi];
            self.player.eating = 0.0;
            self.player.blocking = false;
            self.player.horse_idx = Some(hi);
            self.player.x = h.x;
            self.player.z = h.z;
            self.player.angle = h.angle;
            let name = h.name;
            self.sound_queue.push(SoundEvent::Tone { freq: 220.0, dur: 0.16, power: 0.024, end_freq: 310.0 });
            self.sound_queue.push(SoundEvent::Step(SurfaceKind::Dirt, 1.2));
            self.toast(format!("Mounted {name} — Hold Shift to gallop, E to dismount."), 2.8);
        }
    }

    pub fn eat(&mut self, kind: EatKind, custom_msg: Option<&str>) {
        if self.fishing.is_some() {
            return;
        }
        self.player.armed = false;
        self.player.blocking = false;
        self.player.attack_anim = 0.0;
        self.player.eating = 3.6;
        self.player.eat_kind = kind;
        self.sound_queue.push(SoundEvent::Tone { freq: 330.0, dur: 0.12, power: 0.018, end_freq: 410.0 });
        let msg = custom_msg.unwrap_or(match kind {
            EatKind::Stew => "You savor a hot bowl of Gilded Heron perch stew.",
            EatKind::Bread => "You bite into a warm loaf of village sourdough.",
        });
        self.toast(msg, 2.8);
    }

    pub fn toggle_sword(&mut self) {
        if self.fishing.is_some() {
            return;
        }
        self.player.eating = 0.0;
        self.player.armed = !self.player.armed;
        self.player.draw_anim = 0.42;
        self.player.blocking = false;
        self.sound_queue.push(SoundEvent::Tone {
            freq: if self.player.armed { 620.0 } else { 420.0 },
            dur: 0.14,
            power: 0.024,
            end_freq: if self.player.armed { 980.0 } else { 260.0 },
        });
        self.toast(
            if self.player.armed { "Longsword drawn." } else { "Longsword sheathed." },
            1.6,
        );
    }

    pub fn attack(&mut self, heavy: bool) {
        if self.fishing.is_some() || self.player.attack_anim > 0.14 {
            return;
        }
        self.player.eating = 0.0;
        self.player.blocking = false;
        self.player.block_toggle = false;
        if !self.player.armed {
            self.player.armed = true;
            self.player.draw_anim = 0.18;
        }
        self.player.heavy_attack = heavy;
        self.player.combo = if heavy {
            2
        } else if self.player.combo_timer > 0.0 {
            (self.player.combo + 1) % 3
        } else {
            0
        };
        self.player.attack_anim = if heavy {
            0.74
        } else if self.player.combo == 2 {
            0.62
        } else {
            0.46
        };
        self.player.combo_timer = 1.35;
        self.player.hit_checked = false;
        self.player.angle = (-self.player.yaw.sin()).atan2(-self.player.yaw.cos());
        self.sound_queue.push(SoundEvent::Tone {
            freq: if heavy { 145.0 } else if self.player.combo == 2 { 190.0 } else { 265.0 },
            dur: if heavy { 0.24 } else { 0.16 },
            power: if heavy { 0.04 } else { 0.028 },
            end_freq: if heavy { 58.0 } else if self.player.combo == 2 { 82.0 } else { 110.0 },
        });
        self.sound_queue.push(SoundEvent::Step(SurfaceKind::Grass, if heavy { 0.9 } else { 0.55 }));
    }

    pub fn jump(&mut self) {
        if self.player.jump_h < 0.015 {
            let mounted = self.player.horse_idx.is_some();
            self.player.vy = if mounted { 5.4 } else { 4.3 };
            self.player.jump_h = 0.016;
            self.sound_queue.push(SoundEvent::Step(
                if mounted { SurfaceKind::Dirt } else { SurfaceKind::Grass },
                if mounted { 1.1 } else { 0.2 },
            ));
        }
    }

    /// Returns `Some(npc_idx)` if interaction opens villager dialogue.
    pub fn interact(&mut self) -> Option<usize> {
        let Some(target) = self.target() else {
            self.toast("Walk closer to a villager or the lakeside dock.", 2.4);
            return None;
        };
        match target {
            InteractionTarget::Mount(hi) => self.mount_or_dismount(Some(hi)),
            InteractionTarget::Dismount(_) => self.mount_or_dismount(None),
            InteractionTarget::Bed => {
                self.hour = 7.2;
                self.weather = WeatherKind::Clear;
                self.sound_queue.push(SoundEvent::Reward { big: false });
                self.toast("Rested peacefully in Traveler's Rest. Morning breaks over the Mere.", 3.2);
            }
            InteractionTarget::Door(di) => {
                self.player.interact_anim = 0.38;
                let dr = &mut self.collision.doors[di];
                dr.target = if dr.target > 0.0 { 0.0 } else { 1.0 };
                let opening = dr.target > 0.0;
                self.sound_queue.push(SoundEvent::Tone {
                    freq: if opening { 145.0 } else { 115.0 },
                    dur: 0.22,
                    power: 0.028,
                    end_freq: if opening { 195.0 } else { 85.0 },
                });
                self.sound_queue.push(SoundEvent::Step(SurfaceKind::Wood, 0.8));
            }
            InteractionTarget::Npc(ni) => {
                self.talking = Some(ni);
                self.npcs[ni].speed = 0.0;
                if self.met.insert(ni) {
                    let name = self.npcs[ni].name;
                    self.add_score(15, &format!("Met {name}"), false);
                }
                return Some(ni);
            }
            InteractionTarget::Hammer => {
                self.player.interact_anim = 0.42;
                self.hammer = true;
                self.add_score(30, "The lost hammer, found", false);
            }
            InteractionTarget::Fish => {
                self.player.eating = 0.0;
                self.player.angle = -PI * 0.5;
                self.fishing = Some(FishingState {
                    time: 0.0,
                    pin: 0.5,
                    cast_t: 0.0,
                    bob_x: self.player.x - 4.2,
                    bob_z: self.player.z - 0.25,
                    splashed: false,
                });
                self.sound_queue.push(SoundEvent::Tone { freq: 240.0, dur: 0.18, power: 0.02, end_freq: 520.0 });
            }
            InteractionTarget::Reel => {
                if let Some(f) = self.fishing.take() {
                    let ok = (0.55..=0.81).contains(&f.pin);
                    self.player.reel_anim = 0.75;
                    self.ripple(f.bob_x, f.bob_z);
                    self.burst(f.bob_x, 0.25, f.bob_z, 10, Color::srgb_u8(212, 228, 223));
                    if ok {
                        self.player.catch_anim = 1.25;
                        self.fish = (self.fish + 1).min(3);
                        self.add_score(15, "Silver perch caught", true);
                    } else {
                        self.toast("The fish slipped away. Cast again.", 2.2);
                        self.sound_queue.push(SoundEvent::Step(SurfaceKind::Water, 1.0));
                    }
                }
            }
            InteractionTarget::Well => {
                if self.discover.insert("well".into()) {
                    self.add_score(10, "A wish for the valley", false);
                } else {
                    self.toast("Your wish is safe with the Mere.", 2.4);
                }
            }
            InteractionTarget::Interior { id, msg, building_name, .. } => {
                if id == "inn-bar" || id == "home-table" {
                    self.eat(EatKind::Stew, Some(msg));
                } else if id == "bakery-goods" {
                    self.eat(EatKind::Bread, Some(msg));
                }
                if self.discover.insert(id.into()) {
                    self.add_score(10, &format!("Explored {building_name}"), false);
                } else if id != "inn-bar" && id != "bakery-goods" {
                    self.toast(msg, 3.2);
                }
            }
        }
        None
    }

    pub fn step_simulation(&mut self, dt: f32, move_fwd: f32, move_right: f32, sprint_held: bool, block_held: bool) {
        self.elapsed += dt;
        self.hour = (self.hour + dt * 0.0032 * self.rate) % 24.0;
        if let Some((_, ref mut t)) = self.toast_text {
            *t -= dt;
            if *t <= 0.0 {
                self.toast_text = None;
            }
        }

        self.update_player(dt, move_fwd, move_right, sprint_held, block_held);
        self.update_npcs(dt);

        for dr in &mut self.collision.doors {
            dr.open += (dr.target - dr.open) * (dt * 6.5).min(1.0);
        }
        for dm in &mut self.collision.dummies {
            dm.wobble *= (-dt * 4.2).exp();
        }
        self.shake *= (-dt * 8.0).exp();

        for p in &mut self.particles {
            p.life -= dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
            p.vy -= dt * 2.0;
        }
        self.particles.retain(|p| p.life > 0.0);

        // Merebell gathering
        let (px, pz) = (self.player.x, self.player.z);
        let mut gathered = 0usize;
        for f in &mut self.flowers {
            if !f.taken && (px - f.x).hypot(pz - f.z) < 0.95 {
                f.taken = true;
                gathered += 1;
            }
        }
        for _ in 0..gathered {
            self.add_score(5, "Merebell gathered", false);
        }

        // Fishing minigame update
        let mut splash_pos = None;
        let mut ripple_pos = None;
        if let Some(ref mut f) = self.fishing {
            f.time += dt;
            f.cast_t = (f.time / 0.62).min(1.0);
            if f.cast_t >= 1.0 && !f.splashed {
                f.splashed = true;
                splash_pos = Some((f.bob_x, f.bob_z));
            }
            f.pin = 0.5 + 0.49 * (f.time * 2.7 - 0.8).sin();
            if f.splashed && (0.55..=0.81).contains(&f.pin) && self.elapsed - self.last_ripple[2] > 0.55 {
                ripple_pos = Some((f.bob_x, f.bob_z));
            }
        }
        if let Some((bx, bz)) = splash_pos {
            self.ripple(bx, bz);
            self.burst(bx, 0.22, bz, 8, Color::srgb_u8(212, 228, 223));
            self.sound_queue.push(SoundEvent::Step(SurfaceKind::Water, 1.1));
        }
        if let Some((bx, bz)) = ripple_pos {
            self.ripple(bx, bz);
        }

        if self.elapsed > 900.0 && self.visit_finished.is_none() {
            self.bank_record();
            self.visit_finished = Some(false);
        }
    }

    fn update_player(&mut self, dt: f32, mut f: f32, mut s: f32, sprint_held: bool, block_held: bool) {
        let len = f.hypot(s).max(1.0);
        f /= len;
        s /= len;
        if self.fishing.is_some() {
            f = 0.0;
            s = 0.0;
        }

        if self.player.eating > 0.0 {
            let prev_bite = ((3.6 - self.player.eating) / 1.1).floor() as i32;
            self.player.eating = (self.player.eating - dt).max(0.0);
            let cur_bite = ((3.6 - self.player.eating) / 1.1).floor() as i32;
            if cur_bite > prev_bite && self.player.eating > 0.2 {
                let kind = self.player.eat_kind;
                self.sound_queue.push(SoundEvent::Step(
                    if kind == EatKind::Stew { SurfaceKind::Water } else { SurfaceKind::Wood },
                    0.38,
                ));
                self.burst(
                    self.player.x + self.player.angle.sin() * 0.35,
                    self.player.y + 1.45,
                    self.player.z + self.player.angle.cos() * 0.35,
                    3,
                    if kind == EatKind::Stew { Color::srgb_u8(231, 222, 197) } else { Color::srgb_u8(201, 156, 91) },
                );
            }
        }

        self.player.reel_anim = (self.player.reel_anim - dt).max(0.0);
        self.player.catch_anim = (self.player.catch_anim - dt).max(0.0);
        self.player.draw_anim = (self.player.draw_anim - dt).max(0.0);
        self.player.combo_timer = (self.player.combo_timer - dt).max(0.0);
        self.player.land_anim = (self.player.land_anim - dt).max(0.0);
        self.player.interact_anim = (self.player.interact_anim - dt).max(0.0);
        self.player.blocking = self.player.armed
            && (block_held || self.player.block_toggle)
            && self.player.attack_anim <= 0.0
            && self.fishing.is_none();

        if self.player.attack_anim > 0.0 {
            self.player.attack_anim = (self.player.attack_anim - dt).max(0.0);
            if !self.player.hit_checked && self.player.attack_anim < 0.26 {
                self.player.hit_checked = true;
                let fx = self.player.x + self.player.angle.sin() * 1.35;
                let fz = self.player.z + self.player.angle.cos() * 1.35;
                let mut hit_dummy = false;
                let heavy = self.player.heavy_attack;
                let combo = self.player.combo;
                let p_angle = self.player.angle;
                let mut dummy_burst = Vec::new();
                for dm in &mut self.collision.dummies {
                    if (fx - dm.x).hypot(fz - dm.z) < 1.25 {
                        dm.wobble = if heavy { 1.6 } else if combo == 2 { 1.35 } else { 0.85 };
                        dm.dir = p_angle;
                        hit_dummy = true;
                        dummy_burst.push((dm.x, dm.y + 1.2, dm.z));
                    }
                }
                for (dx, dy, dz) in dummy_burst {
                    self.shake = if heavy { 0.08 } else if combo == 2 { 0.06 } else { 0.03 };
                    self.burst(dx, dy, dz, 14, Color::srgb_u8(217, 183, 117));
                    self.sound_queue.push(SoundEvent::Tone { freq: 155.0, dur: 0.11, power: 0.045, end_freq: 68.0 });
                    self.sound_queue.push(SoundEvent::Step(SurfaceKind::Wood, 1.4));
                }
                if hit_dummy && self.discover.insert("spar".into()) {
                    self.add_score(15, "Practiced swordplay at the yard", false);
                }
                let dmg = if heavy { 38 } else if combo == 2 { 28 } else { 22 };
                let (px, pz) = (self.player.x, self.player.z);
                let mut hit_npcs = Vec::new();
                for (i, n) in self.npcs.iter().enumerate() {
                    if n.activity == NpcActivity::Sleep && n.path.is_empty() {
                        continue;
                    }
                    if (fx - n.x).hypot(fz - n.z) < 1.55 {
                        hit_npcs.push(i);
                    }
                }
                for idx in hit_npcs {
                    self.damage_npc(idx, dmg, px, pz);
                    self.shake = if heavy { 0.075 } else { 0.04 };
                }
            }
        }

        let mounted = self.player.horse_idx.is_some();
        self.player.sprint = sprint_held && f > 0.05;
        let surface = Terrain::surface(&self.buildings, self.player.x, self.player.z);
        let base_v = if mounted {
            if self.player.sprint { 11.2 } else { 5.6 }
        } else if self.player.sprint {
            6.2
        } else {
            3.55
        };
        let v = base_v * if surface == SurfaceKind::Water { 0.55 } else { 1.0 };
        let a = 1.0 - (-dt * if mounted { 9.5 } else { 16.0 }).exp();
        self.player.yaw_vel = (self.player.yaw - self.player.last_yaw) / dt.max(0.004);
        self.player.last_yaw = self.player.yaw;

        let target_vx = (-self.player.yaw.sin() * f + self.player.yaw.cos() * s) * v;
        let target_vz = (-self.player.yaw.cos() * f - self.player.yaw.sin() * s) * v;
        self.player.vx = mix(self.player.vx, target_vx, a);
        self.player.vz = mix(self.player.vz, target_vz, a);

        let mut dyn_cols = Vec::new();
        for n in &self.npcs {
            if n.activity == NpcActivity::Sleep && n.path.is_empty() {
                continue;
            }
            dyn_cols.push((n.x, n.z, 0.34));
        }
        for h in &self.horses {
            if Some(h.id) == self.player.horse_idx {
                continue;
            }
            dyn_cols.push((h.x, h.z, 0.78));
        }

        let col_r = if mounted { 0.66 } else { 0.32 };
        let steps = ((self.player.vx.hypot(self.player.vz) * dt / 0.12).ceil() as usize).max(1);
        let sdt = dt / steps as f32;
        for _ in 0..steps {
            let nx = self.player.x + self.player.vx * sdt;
            let nz = self.player.z + self.player.vz * sdt;
            let can_x = !self.collision.blocked(&self.buildings, nx, self.player.z, col_r, Some(self.player.y), &dyn_cols)
                && (!mounted || Terrain::inside(&self.buildings, nx, self.player.z, 0.18).is_none());
            if can_x {
                self.player.x = nx;
            } else {
                self.player.vx = 0.0;
            }
            let can_z = !self.collision.blocked(&self.buildings, self.player.x, nz, col_r, Some(self.player.y), &dyn_cols)
                && (!mounted || Terrain::inside(&self.buildings, self.player.x, nz, 0.18).is_none());
            if can_z {
                self.player.z = nz;
            } else {
                self.player.vz = 0.0;
            }
        }

        let room_idx = self.buildings.iter().position(|b| {
            b.enterable
                && (self.player.x - b.x).abs() < b.w * 0.5 - 0.05
                && (self.player.z - b.z).abs() < b.d * 0.5 - 0.05
        });
        if room_idx != self.player.current_room {
            self.player.current_room = room_idx;
            if let Some(ri) = room_idx {
                let b = &self.buildings[ri];
                if let Some(sub) = b.subtitle {
                    self.toast(format!("Entered {} — {sub}", b.name), 2.4);
                }
            }
        }

        self.player.speed = self.player.vx.hypot(self.player.vz);
        if self.player.speed > 0.16 {
            let target = self.player.vx.atan2(self.player.vz);
            let diff = (target - self.player.angle).sin().atan2((target - self.player.angle).cos());
            self.player.angle += diff * a;
            self.player.phase += dt * self.player.speed * if mounted { 1.85 } else { 3.0 };
            self.player.steps += dt * self.player.speed;
            if self.player.steps > if mounted { 2.05 } else { 1.58 } {
                self.player.steps = 0.0;
                if mounted {
                    self.sound_queue.push(SoundEvent::Step(SurfaceKind::Dirt, 1.25));
                    if self.player.sprint {
                        self.burst(self.player.x, self.player.y + 0.08, self.player.z, 4, Color::srgb_u8(181, 165, 122));
                    }
                } else {
                    self.sound_queue.push(SoundEvent::Step(surface, 1.0));
                }
                if surface == SurfaceKind::Water {
                    self.ripple(self.player.x, self.player.z);
                }
            }
        }

        if self.player.jump_h > 0.0 || self.player.vy > 0.0 {
            self.player.vy -= 12.5 * dt;
            self.player.jump_h += self.player.vy * dt;
            if self.player.jump_h <= 0.0 {
                self.player.jump_h = 0.0;
                self.player.vy = 0.0;
                self.player.land_anim = 0.22;
                self.shake = if mounted { 0.08 } else { 0.055 };
                self.sound_queue.push(SoundEvent::Step(surface, if mounted { 1.6 } else { 1.3 }));
                self.burst(
                    self.player.x,
                    self.player.y + 0.06,
                    self.player.z,
                    if mounted { 12 } else { 7 },
                    Color::srgb_u8(186, 170, 126),
                );
            }
        }

        let ground_y = Terrain::walk(&self.buildings, self.player.x, self.player.z, Some(self.player.y));
        self.player.on_stairs = room_idx.is_some_and(|ri| {
            let b = &self.buildings[ri];
            b.two_story
                && (ground_y - b.floor_y).abs() > 0.18
                && (ground_y - (b.floor_y + 3.05)).abs() > 0.18
        });
        self.player.y = ground_y + self.player.jump_h;

        if let Some(hi) = self.player.horse_idx {
            let h = &mut self.horses[hi];
            h.x = self.player.x;
            h.z = self.player.z;
            h.y = self.player.y;
            h.angle = self.player.angle;
            h.speed = self.player.speed;
            h.sprint = self.player.sprint;
            h.jump_h = self.player.jump_h;
            h.phase = self.player.phase;
        }
    }

    fn damage_npc(&mut self, idx: usize, dmg: i32, from_x: f32, from_z: f32) {
        let n = &mut self.npcs[idx];
        if n.down_timer > 0.0 {
            return;
        }
        n.hp = (n.hp - dmg).max(0);
        n.hurt_timer = 0.52;
        n.flee_timer = 5.5;
        let dx = n.x - from_x;
        let dz = n.z - from_z;
        let l = dx.hypot(dz).max(1e-4);
        n.hit_dir = dx.atan2(dz);
        n.angle = (-dx).atan2(-dz);
        let impulse = if dmg > 30 { 4.8 } else { 3.1 };
        n.knock_vx = (dx / l) * impulse;
        n.knock_vz = (dz / l) * impulse;
        n.path.clear();
        n.wait = 1.5;
        let (nx, ny, nz, nid, nname, nhp) = (n.x, n.y, n.z, n.id, n.name, n.hp);
        if nhp <= 0 {
            n.down_timer = 8.5;
            n.flee_timer = 0.0;
        }
        self.burst(nx, ny + 1.25, nz, 14, Color::srgb_u8(217, 107, 78));
        self.sound_queue.push(SoundEvent::Tone {
            freq: if nid == 4 { 185.0 } else { 255.0 },
            dur: 0.16,
            power: 0.042,
            end_freq: if nid == 4 { 115.0 } else { 140.0 },
        });
        self.sound_queue.push(SoundEvent::Step(SurfaceKind::Wood, 1.15));
        if nhp <= 0 {
            self.toast(format!("{nname} was knocked down!"), 2.4);
        } else if nid == 4 {
            self.toast(format!("Oswin raises his blade: \"Hold your steel, traveler!\" ({nhp}/100 HP)"), 2.4);
        } else {
            let cries = [
                "\"Watch that blade!\"",
                "\"Mercy, traveler!\"",
                "\"Stop! What are you doing?!\"",
                "\"Help! Put the sword away!\"",
            ];
            self.toast(format!("{nname}: {} ({nhp}/100 HP)", cries[nid % cries.len()]), 2.2);
        }
    }

    fn update_npcs(&mut self, dt: f32) {
        let (px, pz) = (self.player.x, self.player.z);
        let talking = self.talking;
        let night = self.hour < 5.6 || self.hour > 22.0;
        let meal = self.hour > 18.7 && self.hour < 20.3;
        let shelter = self.weather == WeatherKind::Rain;
        let positions: Vec<(f32, f32)> = self.npcs.iter().map(|n| (n.x, n.z)).collect();

        for i in 0..self.npcs.len() {
            let n = &mut self.npcs[i];
            if n.knock_vx.abs() > 0.05 || n.knock_vz.abs() > 0.05 {
                let nx = n.x + n.knock_vx * dt;
                let nz = n.z + n.knock_vz * dt;
                if !self.collision.blocked(&self.buildings, nx, n.z, 0.25, Some(n.y), &[]) {
                    n.x = nx;
                }
                if !self.collision.blocked(&self.buildings, n.x, nz, 0.25, Some(n.y), &[]) {
                    n.z = nz;
                }
                let damp = (-dt * 9.0).exp();
                n.knock_vx *= damp;
                n.knock_vz *= damp;
                n.y = Terrain::walk(&self.buildings, n.x, n.z, Some(n.y));
            }
            if n.hurt_timer > 0.0 {
                n.hurt_timer = (n.hurt_timer - dt).max(0.0);
            }
            if n.down_timer > 0.0 {
                n.down_timer = (n.down_timer - dt).max(0.0);
                n.speed = 0.0;
                if n.down_timer <= 0.0 {
                    n.hp = n.max_hp;
                    n.flee_timer = 0.0;
                }
                continue;
            }
            if n.flee_timer > 0.0 {
                n.flee_timer = (n.flee_timer - dt).max(0.0);
                if n.id == 4 {
                    n.speed = 0.0;
                    n.angle = (px - n.x).atan2(pz - n.z);
                    n.head = 0.0;
                    n.activity = NpcActivity::Guard;
                    continue;
                }
                let dx = n.x - px;
                let dz = n.z - pz;
                let l = dx.hypot(dz).max(1e-4);
                if l < 11.0 {
                    let sp = 2.9;
                    let nx = n.x + (dx / l) * sp * dt;
                    let nz = n.z + (dz / l) * sp * dt;
                    if !self.collision.blocked(&self.buildings, nx, nz, 0.22, Some(n.y), &[]) {
                        n.x = nx;
                        n.z = nz;
                        n.speed = sp;
                        n.angle = dx.atan2(dz);
                        n.phase += sp * dt * 4.5;
                        n.y = Terrain::walk(&self.buildings, n.x, n.z, Some(n.y));
                    } else {
                        n.speed = 0.0;
                    }
                    n.activity = NpcActivity::Flee;
                    continue;
                }
            }

            let pd = (px - n.x).hypot(pz - n.z);
            if talking == Some(i) || pd < 2.8 {
                n.speed = 0.0;
                n.head = (px - n.x).atan2(pz - n.z) - n.angle;
                if talking == Some(i) {
                    n.activity = NpcActivity::Talk;
                }
                continue;
            }
            n.head *= 0.96;
            n.wait -= dt;

            if n.wait <= 0.0 && n.path.is_empty() {
                let b = &self.buildings[n.home];
                let mut dest = n.start;
                n.activity = if night {
                    NpcActivity::Sleep
                } else if shelter {
                    NpcActivity::Shelter
                } else if meal {
                    NpcActivity::Sit
                } else {
                    NpcActivity::Work
                };
                if night || shelter {
                    dest = [b.x, b.z + b.d * 0.5 + 1.1];
                } else if meal {
                    dest = [14.0 + (n.id % 5) as f32 * 1.4, 21.0 + (n.id / 5) as f32 * 1.2];
                } else if n.id == 4 || n.rng.next_f32() < 0.3 {
                    const WANDER_PTS: [[f32; 2]; 6] = [
                        [5.0, 15.0],
                        [5.0, -16.0],
                        [30.0, -11.0],
                        [5.0, 28.0],
                        [-4.0, -8.0],
                        [17.0, 25.0],
                    ];
                    dest = WANDER_PTS[n.rng.next_usize(WANDER_PTS.len())];
                    n.activity = NpcActivity::Wander;
                }
                n.path = find_path(&self.buildings, &self.collision, n.x, n.z, dest[0], dest[1]);
                n.wait = 10.0 + n.rng.next_f32() * 18.0;
            }

            n.speed = 0.0;
            if let Some(&[tx, tz]) = n.path.first() {
                let mut dx = tx - n.x;
                let mut dz = tz - n.z;
                let d = dx.hypot(dz);
                if d < 0.32 {
                    n.path.remove(0);
                } else {
                    let v = (if shelter { 2.1 } else if n.id == 7 { 1.7 } else { 0.85 }) * dt;
                    dx /= d;
                    dz /= d;
                    for (j, &(ox, oz)) in positions.iter().enumerate() {
                        if j == i {
                            continue;
                        }
                        let a = n.x - ox;
                        let b = n.z - oz;
                        let l = a.hypot(b);
                        if l < 0.65 && l > 0.01 {
                            dx += a / l * (0.65 - l);
                            dz += b / l * (0.65 - l);
                        }
                    }
                    let nx = n.x + dx * v;
                    let nz = n.z + dz * v;
                    if !self.collision.blocked(&self.buildings, nx, nz, 0.18, None, &[]) {
                        n.x = nx;
                        n.z = nz;
                        n.speed = v / dt.max(1e-4);
                        n.angle = dx.atan2(dz);
                    } else {
                        n.path.clear();
                        n.wait = 2.0;
                    }
                    n.phase += n.speed * dt * 5.0;
                }
            }
            n.y = Terrain::walk(&self.buildings, n.x, n.z, None);
        }
    }

    pub fn bank_record(&mut self) {
        self.records.push(VisitRecord {
            score: self.score,
            quests: (self.fish_quest == 2) as u8 + (self.hammer_quest == 2) as u8,
            met: self.met.len(),
            seconds: self.elapsed.round() as u32,
        });
        self.records.sort_by(|a, b| {
            b.score
                .cmp(&a.score)
                .then(b.quests.cmp(&a.quests))
                .then(a.seconds.cmp(&b.seconds))
        });
        self.records.truncate(5);
    }

    pub fn look_by(&mut self, dx: f32, dy: f32) {
        self.player.yaw -= clamp(dx, -130.0, 130.0) * 0.0031;
        let min_p = if self.player.first_person { -0.99 } else { -0.28 };
        let max_p = if self.player.first_person { 1.02 } else { 1.13 };
        self.player.pitch = clamp(
            self.player.pitch + clamp(dy, -100.0, 100.0) * 0.0024,
            min_p,
            max_p,
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn quests_and_objective_progression() {
        let mut world = HollowmereWorld::new();
        assert_eq!(world.objective(), "Meet Elin, the innkeeper");
        world.fish_quest = 1;
        assert_eq!(world.objective(), "Catch fish at the lake dock (0/3)");
        world.fish = 3;
        assert_eq!(world.objective(), "Bring three fish to Elin");
        world.fish_quest = 2;
        assert_eq!(world.objective(), "Speak with Rowan at the forge");
        world.hammer_quest = 1;
        world.hammer = true;
        assert_eq!(world.objective(), "Return the hammer to Rowan");
        world.hammer_quest = 2;
        assert_eq!(world.objective(), "A friend to the village");
    }

    #[test]
    fn horse_mount_and_dismount_works() {
        let mut world = HollowmereWorld::new();
        assert!(world.player.horse_idx.is_none());
        world.mount_or_dismount(Some(0));
        assert_eq!(world.player.horse_idx, Some(0));
        world.mount_or_dismount(None);
        assert!(world.player.horse_idx.is_none());
    }
}
