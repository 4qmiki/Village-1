pub mod audio;
pub mod collision;
pub mod data;
pub mod input_and_ui;
pub mod math;
pub mod pathfinding;
pub mod procedural_textures;
pub mod terrain;
pub mod world_render;
pub mod world_state;

use bevy::prelude::*;
use bevy_rapier3d::prelude::*;

use crate::audio::{update_procedural_audio, ProceduralAudioState};
use crate::data::AppScreen;
use crate::input_and_ui::{handle_input_and_step, handle_ui_buttons, setup_ui, sync_ui, TouchStickState};
use crate::world_render::{setup_3d_world, sync_visuals_and_camera, SkyMaterial, WaterMaterial};
use crate::world_state::{GameSettings, HollowmereWorld};

#[bevy_main]
pub fn main() {
    run_app();
}

pub fn run_app() {
    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window {
                title: "Hollowmere | A Medieval Exploration".into(),
                resizable: true,
                ..default()
            }),
            ..default()
        }))
        .add_plugins(RapierPhysicsPlugin::<NoUserData>::default())
        .add_plugins(MaterialPlugin::<SkyMaterial>::default())
        .add_plugins(MaterialPlugin::<WaterMaterial>::default())
        .init_state::<AppScreen>()
        .insert_resource(GameSettings::default())
        .insert_resource(HollowmereWorld::new())
        .insert_resource(TouchStickState::default())
        .insert_resource(ProceduralAudioState::default())
        .add_systems(Startup, (setup_3d_world, setup_ui))
        .add_systems(
            Update,
            (
                handle_input_and_step,
                handle_ui_buttons,
                sync_visuals_and_camera,
                sync_ui,
                update_procedural_audio,
            )
                .chain(),
        )
        .run();
}
