use std::f32::consts::TAU;
use std::sync::OnceLock;

pub const TWO_PI: f32 = TAU;

/// Bit-exact Mulberry32 PRNG matching the original JS `seeded(seed)`.
#[derive(Debug, Clone)]
pub struct SeededRng {
    seed: i32,
}

impl SeededRng {
    pub fn new(seed: i32) -> Self {
        Self { seed }
    }

    pub fn next_f32(&mut self) -> f32 {
        self.seed = self.seed.wrapping_add(0x6D2B_79F5_u32 as i32);
        let mut t = (self.seed ^ ((self.seed as u32) >> 15) as i32)
            .wrapping_mul(1 | self.seed);
        t = (t.wrapping_add(
            (t ^ ((t as u32) >> 7) as i32).wrapping_mul(61 | t),
        )) ^ t;
        let u = (t as u32) ^ ((t as u32) >> 14);
        (u as f64 / 4_294_967_296.0) as f32
    }

    pub fn next_usize(&mut self, max: usize) -> usize {
        if max == 0 {
            return 0;
        }
        ((self.next_f32() * max as f32) as usize).min(max - 1)
    }
}

#[inline]
pub fn clamp(x: f32, a: f32, b: f32) -> f32 {
    x.clamp(a, b)
}

#[inline]
pub fn mix(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}

#[inline]
pub fn smooth(a: f32, b: f32, v: f32) -> f32 {
    let t = clamp((v - a) / (b - a), 0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

#[inline]
pub fn dist_seg(x: f32, z: f32, a: f32, b: f32, c: f32, d: f32) -> f32 {
    let denom = (c - a).powi(2) + (d - b).powi(2);
    let t = if denom == 0.0 {
        0.0
    } else {
        clamp(((x - a) * (c - a) + (z - b) * (d - b)) / denom, 0.0, 1.0)
    };
    (x - a - t * (c - a)).hypot(z - b - t * (d - b))
}

fn noise_table() -> &'static [f32; 65536] {
    static TABLE: OnceLock<Box<[f32; 65536]>> = OnceLock::new();
    TABLE.get_or_init(|| {
        let mut rng = SeededRng::new(981);
        let mut arr = vec![0.0f32; 65536].into_boxed_slice();
        for v in arr.iter_mut() {
            *v = rng.next_f32();
        }
        arr.try_into().expect("noise table length is 65536")
    })
}

pub fn noise(x: f32, y: f32) -> f32 {
    let i = x.floor() as i32;
    let j = y.floor() as i32;
    let mut a = x - i as f32;
    let mut b = y - j as f32;
    a = a * a * (3.0 - 2.0 * a);
    b = b * b * (3.0 - 2.0 * b);
    let tbl = noise_table();
    let sample = |u: i32, v: i32| -> f32 {
        let idx = ((u & 255) as usize) + (((v & 255) as usize) << 8);
        tbl[idx]
    };
    mix(
        mix(sample(i, j), sample(i + 1, j), a),
        mix(sample(i, j + 1), sample(i + 1, j + 1), a),
        b,
    )
}

pub fn fbm(x: f32, y: f32) -> f32 {
    noise(x, y) * 0.53
        + noise(x * 2.1 + 13.0, y * 2.1) * 0.27
        + noise(x * 4.3, y * 4.3 + 4.0) * 0.133
        + noise(x * 8.7, y * 8.7) * 0.067
}

pub fn fmt_time(hour: f32) -> String {
    let wrapped = ((hour % 24.0) + 24.0) % 24.0;
    let total_mins = (wrapped * 60.0).floor() as u32;
    format!("{:02}:{:02}", (total_mins / 60) % 24, total_mins % 60)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mulberry32_is_deterministic() {
        let mut a = SeededRng::new(981);
        let mut b = SeededRng::new(981);
        for _ in 0..32 {
            assert_eq!(a.next_f32(), b.next_f32());
        }
    }

    #[test]
    fn noise_and_fbm_bounded() {
        for i in -10..10 {
            let n = noise(i as f32 * 0.37, i as f32 * 0.21);
            let f = fbm(i as f32 * 0.13, i as f32 * 0.19);
            assert!((0.0..=1.0).contains(&n));
            assert!((0.0..=1.0).contains(&f));
        }
    }

    #[test]
    fn time_formatting_matches_js() {
        assert_eq!(fmt_time(17.5), "17:30");
        assert_eq!(fmt_time(7.2), "07:12");
        assert_eq!(fmt_time(24.0), "00:00");
    }
}
