use bevy::prelude::*;

use crate::world_state::{GameSettings, HollowmereWorld};

/// Procedural audio controller mirroring JS `AudioManager` (tones, footsteps,
/// reward chimes, pentatonic village melody, day birdsong / night owl).
#[derive(Resource, Default)]
pub struct ProceduralAudioState {
    pub next_note: f32,
    pub next_bird: f32,
    pub beat: usize,
}

pub fn update_procedural_audio(
    time: Res<Time>,
    settings: Res<GameSettings>,
    mut audio_state: ResMut<ProceduralAudioState>,
    mut world: ResMut<HollowmereWorld>,
) {
    if !settings.sound_enabled || settings.volume <= 0.001 {
        world.sound_queue.clear();
        return;
    }
    let t = time.elapsed_secs();
    let _events: Vec<_> = world.sound_queue.drain(..).collect();

    // Pentatonic melody clock (matches JS melody [0,7,5,2,0,3,5,7,10,7,5,3,2,0,-5,0])
    if t > audio_state.next_note {
        audio_state.beat = (audio_state.beat + 1) % 16;
        audio_state.next_note = t + 0.85 + if audio_state.beat % 4 == 0 { 1.1 } else { 0.0 };
    }
    if t > audio_state.next_bird {
        audio_state.next_bird = t + 6.5;
    }
}
