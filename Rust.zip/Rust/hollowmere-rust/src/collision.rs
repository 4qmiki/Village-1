use std::collections::HashMap;

use crate::data::{BuildingKind, BuildingSpec};
use crate::math::dist_seg;
use crate::terrain::Terrain;

pub const COL_CELL: f32 = 6.0;

#[derive(Debug, Clone)]
pub enum ObstacleKind {
    Box { x: f32, z: f32, w: f32, d: f32 },
    Circle { x: f32, z: f32, r: f32 },
    Seg { ax: f32, az: f32, bx: f32, bz: f32, r: f32 },
}

#[derive(Debug, Clone)]
pub struct Obstacle {
    pub kind: ObstacleKind,
    pub h: f32,
    pub min_y: f32,
}

#[derive(Debug, Clone)]
pub struct DoorState {
    pub name: &'static str,
    pub x: f32,
    pub z: f32,
    pub w: f32,
    pub open: f32,
    pub target: f32,
}

#[derive(Debug, Clone)]
pub struct DummyState {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub wobble: f32,
    pub dir: f32,
}

#[derive(Debug, Clone)]
pub struct CollisionWorld {
    pub obstacles: Vec<Obstacle>,
    pub grid: HashMap<(i32, i32), Vec<usize>>,
    pub doors: Vec<DoorState>,
    pub dummies: Vec<DummyState>,
}

impl CollisionWorld {
    pub fn new(buildings: &[BuildingSpec]) -> Self {
        let mut world = Self {
            obstacles: Vec::new(),
            grid: HashMap::new(),
            doors: Vec::new(),
            dummies: Vec::new(),
        };

        for b in buildings {
            let base_y = if b.enterable {
                b.floor_y
            } else {
                Terrain::height(b.x, b.z)
            };
            let top_h = base_y + b.h + b.roof + 1.7;
            if !b.enterable {
                world.add_box(b.x, b.z, b.w * 0.5 + 0.16, b.d * 0.5 + 0.16, top_h, -10.0);
            } else {
                let wt = 0.28;
                let hw = b.w * 0.5;
                let hd = b.d * 0.5;
                let side_w = (b.w - b.door_w) * 0.5;
                world.add_wall_box(b.x, b.z - hd, b.w + wt, wt, top_h, -10.0);
                world.add_wall_box(b.x - hw, b.z, wt, b.d + wt, top_h, -10.0);
                world.add_wall_box(b.x + hw, b.z, wt, b.d + wt, top_h, -10.0);
                world.add_wall_box(b.x - hw + side_w * 0.5, b.z + hd, side_w, wt, top_h, -10.0);
                world.add_wall_box(b.x + hw - side_w * 0.5, b.z + hd, side_w, wt, top_h, -10.0);

                let start_open = if matches!(b.kind, BuildingKind::Inn | BuildingKind::Bakery) {
                    1.0
                } else {
                    0.0
                };
                world.doors.push(DoorState {
                    name: b.name,
                    x: b.x,
                    z: b.z + hd,
                    w: b.door_w,
                    open: start_open,
                    target: start_open,
                });
            }
        }

        // Village square well & two market stalls
        world.add_box(9.5, -0.6, 1.2, 1.2, 4.4, -10.0);
        world.add_box(14.2, 1.4, 1.95, 1.1, 4.7, -10.0);
        world.add_box(17.9, 2.0, 1.35, 1.1, 4.5, -10.0);

        // Sparring dummies
        for [dx, dz] in crate::data::DUMMY_SPOTS {
            let dy = Terrain::walk(buildings, dx, dz, None);
            world.add_circle(dx, dz, 0.42, dy + 2.0, -10.0);
            world.dummies.push(DummyState {
                x: dx,
                y: dy,
                z: dz,
                wobble: 0.0,
                dir: 0.0,
            });
        }

        world
    }

    pub fn add_obstacle(&mut self, obs: Obstacle) {
        let (min_x, max_x, min_z, max_z) = match obs.kind {
            ObstacleKind::Box { x, z, w, d } => (x - w, x + w, z - d, z + d),
            ObstacleKind::Circle { x, z, r } => (x - r, x + r, z - r, z + r),
            ObstacleKind::Seg { ax, az, bx, bz, r } => (
                ax.min(bx) - r,
                ax.max(bx) + r,
                az.min(bz) - r,
                az.max(bz) + r,
            ),
        };
        let idx = self.obstacles.len();
        self.obstacles.push(obs);
        let ix0 = (min_x / COL_CELL).floor() as i32;
        let ix1 = (max_x / COL_CELL).floor() as i32;
        let iz0 = (min_z / COL_CELL).floor() as i32;
        let iz1 = (max_z / COL_CELL).floor() as i32;
        for ix in ix0..=ix1 {
            for iz in iz0..=iz1 {
                self.grid.entry((ix, iz)).or_default().push(idx);
            }
        }
    }

    pub fn add_box(&mut self, x: f32, z: f32, half_w: f32, half_d: f32, h: f32, min_y: f32) {
        self.add_obstacle(Obstacle {
            kind: ObstacleKind::Box { x, z, w: half_w, d: half_d },
            h,
            min_y,
        });
    }

    pub fn add_wall_box(&mut self, x: f32, z: f32, w: f32, d: f32, h: f32, min_y: f32) {
        self.add_box(x, z, w * 0.5, d * 0.5, h, min_y);
    }

    pub fn add_circle(&mut self, x: f32, z: f32, r: f32, h: f32, min_y: f32) {
        self.add_obstacle(Obstacle {
            kind: ObstacleKind::Circle { x, z, r },
            h,
            min_y,
        });
    }

    pub fn add_seg(&mut self, ax: f32, az: f32, bx: f32, bz: f32, r: f32, h: f32, min_y: f32) {
        self.add_obstacle(Obstacle {
            kind: ObstacleKind::Seg { ax, az, bx, bz, r },
            h,
            min_y,
        });
    }

    pub fn hit_obstacle(obs: &Obstacle, x: f32, z: f32, r: f32, py: Option<f32>) -> bool {
        if let Some(y) = py {
            if y + 1.65 < obs.min_y || y > obs.h - 0.08 {
                return false;
            }
        }
        match obs.kind {
            ObstacleKind::Circle { x: ox, z: oz, r: or } => (x - ox).hypot(z - oz) < or + r,
            ObstacleKind::Seg { ax, az, bx, bz, r: sr } => dist_seg(x, z, ax, az, bx, bz) < sr + r,
            ObstacleKind::Box { x: ox, z: oz, w, d } => {
                (x - ox).abs() < w + r && (z - oz).abs() < d + r
            }
        }
    }

    pub fn hit_obstacle_3d(&self, x: f32, y: f32, z: f32, pad: f32) -> bool {
        let ix = (x / COL_CELL).floor() as i32;
        let iz = (z / COL_CELL).floor() as i32;
        if let Some(bucket) = self.grid.get(&(ix, iz)) {
            for &idx in bucket {
                let obs = &self.obstacles[idx];
                if y > obs.h + 0.15 {
                    continue;
                }
                let hit = match obs.kind {
                    ObstacleKind::Circle { x: ox, z: oz, r } => (x - ox).hypot(z - oz) < r + pad,
                    ObstacleKind::Seg { ax, az, bx, bz, r } => {
                        dist_seg(x, z, ax, az, bx, bz) < r + pad
                    }
                    ObstacleKind::Box { x: ox, z: oz, w, d } => {
                        (x - ox).abs() < w + pad && (z - oz).abs() < d + pad
                    }
                };
                if hit {
                    return true;
                }
            }
        }
        false
    }

    pub fn blocked(
        &self,
        buildings: &[BuildingSpec],
        x: f32,
        z: f32,
        r: f32,
        py: Option<f32>,
        dynamic_circles: &[(f32, f32, f32)],
    ) -> bool {
        if (x - 5.0).abs() > 96.0 || z.abs() > 98.0 {
            return true;
        }
        if !Terrain::dock(x, z) && Terrain::lake(x, z) < 0.945 {
            return true;
        }
        if Terrain::inside(buildings, x, z, 0.5).is_none() && !Terrain::dock(x, z) {
            let h0 = Terrain::height(x, z);
            if h0 > 13.5 {
                return true;
            }
            let slope = (Terrain::height(x + 0.6, z) - h0)
                .hypot(Terrain::height(x, z + 0.6) - h0)
                / 0.6;
            if slope > 1.15 {
                return true;
            }
        }
        for dr in &self.doors {
            if dr.open < 0.55 && (x - dr.x).abs() < dr.w * 0.5 + r && (z - dr.z).abs() < 0.22 + r {
                return true;
            }
        }
        let ix0 = ((x - r - 0.1) / COL_CELL).floor() as i32;
        let ix1 = ((x + r + 0.1) / COL_CELL).floor() as i32;
        let iz0 = ((z - r - 0.1) / COL_CELL).floor() as i32;
        let iz1 = ((z + r + 0.1) / COL_CELL).floor() as i32;
        for ix in ix0..=ix1 {
            for iz in iz0..=iz1 {
                if let Some(bucket) = self.grid.get(&(ix, iz)) {
                    for &idx in bucket {
                        if Self::hit_obstacle(&self.obstacles[idx], x, z, r, py) {
                            return true;
                        }
                    }
                }
            }
        }
        for &(cx, cz, cr) in dynamic_circles {
            if (x - cx).hypot(z - cz) < r + cr {
                return true;
            }
        }
        false
    }
}
