fn main() {
    hollowmere::run_app();
}
