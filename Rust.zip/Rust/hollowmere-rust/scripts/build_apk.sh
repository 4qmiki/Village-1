#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# Build Hollowmere Native Rust Library + Installable Android APK
# Targets: arm64-v8a (primary, e.g. Redmi Note 14 Pro+ 5G) and armeabi-v7a
# ==============================================================================

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

: "${ANDROID_HOME:=$HOME/Android/Sdk}"
: "${ANDROID_NDK_HOME:=$ANDROID_HOME/ndk/27.2.12479018}"
export ANDROID_HOME ANDROID_NDK_HOME

echo "==> [1/4] Running Rust unit tests..."
cargo test --lib

echo "==> [2/4] Cross-compiling libhollowmere.so with cargo-ndk..."
mkdir -p android/app/src/main/jniLibs
cargo ndk \
  -t arm64-v8a \
  -t armeabi-v7a \
  -p 28 \
  -o android/app/src/main/jniLibs \
  build --release --lib

echo "==> [3/4] Copying WGSL shaders & assets into Android APK bundle..."
rm -rf android/app/src/main/assets
mkdir -p android/app/src/main/assets
cp -r assets/* android/app/src/main/assets/

echo "==> [4/4] Building Android APK via Gradle..."
cd android
if [ -x "./gradlew" ]; then
  ./gradlew assembleDebug
else
  gradle assembleDebug
fi

APK_PATH="$ROOT_DIR/android/app/build/outputs/apk/debug/app-debug.apk"
echo "==> APK ready: $APK_PATH"
echo "==> Install via ADB: adb install -r \"$APK_PATH\""
