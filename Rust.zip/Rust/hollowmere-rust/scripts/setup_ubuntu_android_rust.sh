#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# Hollowmere Ubuntu Development Environment Setup
# Installs: OpenJDK 17, Android SDK (API 34), Android NDK r27c, Rustup, Cargo,
#           Android Rust targets, cargo-ndk, and rust-anything CLI.
# ==============================================================================

echo "==> [1/6] Installing Ubuntu system dependencies & OpenJDK 17..."
sudo apt-get update
sudo apt-get install -y \
  build-essential curl git unzip zip pkg-config cmake clang lld \
  openjdk-17-jdk libasound2-dev libudev-dev libx11-dev libxcursor-dev \
  libxi-dev libxrandr-dev libwayland-dev libxkbcommon-dev

export JAVA_HOME="/usr/lib/jvm/java-17-openjdk-amd64"

echo "==> [2/6] Installing Rust & Cargo via rustup..."
if ! command -v rustup >/dev/null 2>&1; then
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
fi
source "$HOME/.cargo/env"
rustup update stable
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android

echo "==> [3/6] Installing cargo-ndk and rust-anything..."
cargo install cargo-ndk
cargo install rust-anything || echo "Note: Install rust-anything from crates.io/source if unavailable."

echo "==> [4/6] Installing Android SDK Command-Line Tools..."
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
mkdir -p "$ANDROID_HOME/cmdline-tools"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  CMDLINE_ZIP="/tmp/commandlinetools-linux.zip"
  curl -fsSL "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -o "$CMDLINE_ZIP"
  unzip -q "$CMDLINE_ZIP" -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm -f "$CMDLINE_ZIP"
fi

export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

echo "==> [5/6] Installing Android Platform 34, Build-Tools 34.0.0, and NDK 27.2.12479018..."
yes | sdkmanager --licenses >/dev/null || true
sdkmanager \
  "platform-tools" \
  "platforms;android-34" \
  "build-tools;34.0.0" \
  "ndk;27.2.12479018"

export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/27.2.12479018"

echo "==> [6/6] Persisting environment variables to ~/.bashrc..."
grep -q "ANDROID_NDK_HOME" "$HOME/.bashrc" || cat <<'EOF' >> "$HOME/.bashrc"

# Hollowmere Rust + Android SDK/NDK Environment
export JAVA_HOME="/usr/lib/jvm/java-17-openjdk-amd64"
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/27.2.12479018"
export PATH="$HOME/.cargo/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
EOF

echo "==> Verification:"
java -version
javac -version
rustc --version
cargo --version
cargo ndk --version
sdkmanager --version
echo "==> Done! Run 'source ~/.bashrc' and then './scripts/build_apk.sh'."
