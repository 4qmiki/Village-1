#import bevy_pbr::forward_io::VertexOutput

struct WaterUniforms {
    sun_dir: vec3<f32>,
    time: f32,
    sun_color: vec3<f32>,
    wetness: f32,
    water_color: vec3<f32>,
    day: f32,
    ripple_event: vec3<f32>,
    _pad: f32,
};

@group(2) @binding(0)
var<uniform> u: WaterUniforms;

@fragment
fn fragment(in: VertexOutput) -> @location(0) vec4<f32> {
    let wp = in.world_position.xyz;
    let t = u.time;
    let w1 = sin(wp.x * 0.55 + t * 1.15) * cos(wp.z * 0.48 - t * 0.95);
    let w2 = sin(wp.x * 1.35 - t * 1.65 + wp.z * 0.9);
    var n = normalize(vec3<f32>(w1 * 0.08 + w2 * 0.04, 1.0, w2 * 0.07 - w1 * 0.05));

    let dist_rip = length(wp.xz - u.ripple_event.xy);
    let age = t - u.ripple_event.z;
    let rip = sin(dist_rip * 19.0 - age * 12.0)
        * exp(-abs(dist_rip - age * 1.8) * 3.0)
        * exp(-age * 1.4)
        * step(0.0, age);
    let rdir = normalize(wp.xz - u.ripple_event.xy + vec2<f32>(0.0001, 0.0));
    n = normalize(vec3<f32>(
        n.x + rdir.x * rip * 0.23 + u.wetness * 0.06 * sin(wp.x * 17.0 + t * 7.0),
        1.0,
        n.z + rdir.y * rip * 0.23 + u.wetness * 0.06 * sin(wp.z * 17.0 + t * 7.0)
    ));

    let view_dir = normalize(vec3<f32>(0.0, 8.0, 20.0) - wp);
    let fresnel = pow(1.0 - max(dot(view_dir, n), 0.0), 3.2);
    let refl_dir = reflect(-u.sun_dir, n);
    let spec = pow(max(dot(view_dir, refl_dir), 0.0), 96.0);

    var albedo = mix(u.water_color, u.sun_color * (0.45 + u.day * 0.4), clamp(fresnel * 0.65, 0.0, 0.8));
    let edge = length((wp.xz - vec2<f32>(-53.0, -18.0)) / vec2<f32>(46.0, 54.0));
    let shore = smoothstep(0.93, 1.035, edge);
    albedo = mix(albedo, vec3<f32>(0.16, 0.195, 0.105), shore * 0.38);
    albedo += vec3<f32>(0.18, 0.21, 0.16) * smoothstep(0.995, 1.01, edge) * (0.5 + 0.5 * sin(edge * 620.0 + t * 0.8));
    albedo += u.sun_color * spec * 1.15;

    return vec4<f32>(albedo, 0.94);
}
