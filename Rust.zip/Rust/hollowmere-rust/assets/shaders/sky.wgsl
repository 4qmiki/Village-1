#import bevy_pbr::forward_io::VertexOutput

struct SkyUniforms {
    sun_dir: vec3<f32>,
    day: f32,
    wet: f32,
    time: f32,
    _pad: vec2<f32>,
};

@group(2) @binding(0)
var<uniform> u: SkyUniforms;

fn hash2(p: vec2<f32>) -> f32 {
    return fract(sin(dot(p, vec2<f32>(127.1, 311.7))) * 43758.5453123);
}

fn noise2(p: vec2<f32>) -> f32 {
    let i = floor(p);
    var f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(hash2(i), hash2(i + vec2<f32>(1.0, 0.0)), f.x),
        mix(hash2(i + vec2<f32>(0.0, 1.0)), hash2(i + vec2<f32>(1.0, 1.0)), f.x),
        f.y
    );
}

fn fbm2(p_in: vec2<f32>) -> f32 {
    var p = p_in;
    var v = 0.0;
    var a = 0.52;
    let m = mat2x2<f32>(0.8, -0.6, 0.6, 0.8);
    for (var i = 0; i < 5; i = i + 1) {
        v = v + a * noise2(p);
        p = m * p * 2.04 + vec2<f32>(11.3, 7.1);
        a = a * 0.5;
    }
    return v;
}

fn cloud_density(p: vec2<f32>) -> f32 {
    let w = vec2<f32>(
        fbm2(p * 0.65 + vec2<f32>(u.time * 0.004, 0.0)),
        fbm2(p * 0.65 + vec2<f32>(5.2, -u.time * 0.003))
    );
    return fbm2(p + w * 0.42);
}

@fragment
fn fragment(in: VertexOutput) -> @location(0) vec4<f32> {
    let d = normalize(in.world_position.xyz);
    let h = max(0.0, d.y);
    let s = max(0.0, dot(d, u.sun_dir));
    let sun_elev = clamp(u.sun_dir.y * 2.4 + 0.15, 0.0, 1.0);
    let golden = 1.0 - smoothstep(0.04, 0.55, max(u.sun_dir.y, 0.0));

    let zenith_day = mix(vec3<f32>(0.14, 0.28, 0.49), vec3<f32>(0.19, 0.41, 0.66), sun_elev);
    let horizon_day = mix(vec3<f32>(0.67, 0.74, 0.73), vec3<f32>(1.26, 0.76, 0.41), golden * 0.72 + 0.14);
    var sky = mix(horizon_day, zenith_day, pow(h, 0.46));

    sky += vec3<f32>(1.15, 0.62, 0.28) * pow(1.0 - h, 4.5) * golden * 0.36;
    let mie = pow(s, 8.0) * 0.45 + pow(s, 48.0) * 0.72 + pow(s, 256.0) * 1.2;
    sky += mix(vec3<f32>(1.0, 0.86, 0.62), vec3<f32>(1.35, 0.72, 0.32), golden) * mie * (0.35 + u.day * 0.65);

    let c_uv = d.xz / (h + 0.14);
    let cirrus = smoothstep(0.54, 0.84, fbm2(vec2<f32>(c_uv.x * 2.4 + u.time * 0.0025, c_uv.y * 5.8 + 3.1)))
        * smoothstep(0.05, 0.28, h) * (1.0 - u.wet * 0.5);
    let cirrus_col = mix(vec3<f32>(0.88, 0.91, 0.92), vec3<f32>(1.42, 1.02, 0.68), golden * 0.85);
    sky = mix(sky, cirrus_col, cirrus * 0.42);

    let uv = c_uv * 0.88 + vec2<f32>(u.time * 0.0055, u.time * 0.0018);
    let dens = cloud_density(uv * 1.75 + vec2<f32>(12.0, 12.0));
    let cover = mix(0.47, 0.34, u.wet);
    let cloud = smoothstep(cover, cover + 0.28, dens) * smoothstep(0.018, 0.22, h);
    let sun_step = normalize(u.sun_dir.xz + vec2<f32>(0.0001, 0.0)) * 0.14;
    let shadow_sample = cloud_density((uv + sun_step) * 1.75 + vec2<f32>(12.0, 12.0));
    let lit = clamp(1.0 - (shadow_sample - dens) * 3.6, 0.0, 1.0);
    let silver = pow(s, 7.0) * (1.0 - cloud * 0.55) * smoothstep(cover - 0.04, cover + 0.14, dens);
    let cloud_dark = mix(vec3<f32>(0.42, 0.48, 0.53), vec3<f32>(0.56, 0.46, 0.47), golden * 0.75);
    let cloud_bright = mix(vec3<f32>(1.06, 1.05, 1.01), vec3<f32>(1.52, 1.12, 0.68), golden * 0.88);
    var cc = mix(cloud_dark, cloud_bright, smoothstep(0.15, 0.85, lit));
    cc += vec3<f32>(1.35, 1.1, 0.72) * silver * 0.58;
    sky = mix(sky, cc, cloud * 0.91);
    sky += vec3<f32>(4.2, 3.1, 1.65) * smoothstep(0.99945, 0.9999, s) * (1.0 - cloud * 0.84);

    // Night sky: Milky Way, twinkling stars, cratered Moon
    var night = mix(vec3<f32>(0.048, 0.072, 0.108), vec3<f32>(0.007, 0.016, 0.042), pow(h, 0.58));
    let mw_band = exp(-pow((d.x * 0.72 - d.z * 0.55 + d.y * 0.38) * 3.1, 2.0)) * smoothstep(0.06, 0.38, h);
    let mw_cloud = fbm2(d.xz / (h + 0.45) * 4.2 + vec2<f32>(3.1, 9.4));
    night += vec3<f32>(0.06, 0.075, 0.115) * mw_band * mw_cloud;
    let s_grid = floor(d.xz / (h + 0.18) * 640.0);
    let s_rand = hash2(s_grid);
    let twinkle = 0.72 + 0.28 * sin(u.time * 2.6 + s_rand * 40.0);
    let star = step(0.9968, s_rand) * smoothstep(0.08, 0.45, h) * twinkle;
    let star_col = mix(vec3<f32>(0.78, 0.86, 1.0), vec3<f32>(1.0, 0.91, 0.74), fract(s_rand * 137.0));
    night += star_col * star * 1.25;

    let moon_dir = normalize(-u.sun_dir);
    let m_dot = dot(d, moon_dir);
    night += vec3<f32>(0.16, 0.21, 0.28) * pow(max(0.0, m_dot), 28.0);
    if (m_dot > 0.9988) {
        let tangent = normalize(cross(vec3<f32>(0.0, 1.0, 0.0), moon_dir) + vec3<f32>(0.0001, 0.0, 0.0));
        let m_uv = vec2<f32>(dot(d - moon_dir, tangent), d.y - moon_dir.y) * 36.0;
        let crater = fbm2(m_uv * 3.5 + vec2<f32>(4.2, 4.2));
        let m_mask = smoothstep(0.9988, 0.99925, m_dot);
        night = mix(night, vec3<f32>(0.96, 0.95, 0.86) * (0.76 + crater * 0.34), m_mask);
    }

    var color = mix(night, sky, u.day);
    color = mix(color, vec3<f32>(0.36, 0.44, 0.45) * (0.24 + u.day * 0.76), u.wet * 0.52);
    return vec4<f32>(color, 1.0);
}
